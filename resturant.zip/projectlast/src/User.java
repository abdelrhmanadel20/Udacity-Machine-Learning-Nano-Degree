public class User {
    
    private int id;
    private String address;
    private String name;
    private int contact;
    
    
    public User(int idcustomer,String name,String address,int contactno)
    {
        this.id = idcustomer;
        this.name = name;
        this.address = address;
        this.contact = contactno;
    }
    
    public int getidcustomer()
    {
        return id;
    }
    
    public String getcustomerName()
    {
        return name;
    }
    
    public String getaddress()
    {
        return address;
    }
    
    public int getcontactno()
    {
        return contact;
    }
}
