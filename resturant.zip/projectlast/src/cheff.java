public class cheff {
    
    private int id;
    private String address;
    private String name;
    private int contact;
      private int salary;
    
    public cheff(int idcheff,String name,String address,int contactno,int salary)
    {
        this.id = idcheff;
        this.name = name;
        this.address = address;
        this.contact = contactno;
          this.salary = salary;
    }
    
    public int getidcheff()
    {
        return id;
    }
     public int getsalarycheff()
    {
        return salary;
    }
    
    public String getcheffName()
    {
        return name;
    }
    
    public String getcheffaddress()
    {
        return address;
    }
    
    public int getcheffcontactno()
    {
        return contact;
    }
}
