
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import java.util.Locale;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.text.*;
import java.awt.print.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JTable;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Abd Elrhman Elattar
 */
public class NewJFrame extends javax.swing.JFrame {

     // methodes
     public void GetData(){ // menampilkan data dari database
        try {
            
            Connection conn =getConnection("c");
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet sql = stm.executeQuery("select * from customer");
            jTable1.setModel(DbUtils.resultSetToTableModel(sql));
            
        } 
        catch (SQLException | HeadlessException e){
        }
    }
     
     private void showin(){ //uncmpleat
     
     
         try {
             Connection conn =getConnection("c");
             java.sql.Statement stm = conn.createStatement();
             java.sql.ResultSet sql = stm.executeQuery("select iteamNo,iteamname,price,quantity from iteams where `order_id`="+orderNo.getText() );
             
             while( sql.next()){
                 jTextarea.setText(sql.getString(1)+"                                 "+sql.getString(2)
                         +"                                 "+sql.getString(3)+"                                 "+sql.getString(4));
                 
             } } catch (SQLException ex) {
             Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
    private void GEtmun(){ //
        try {
                    

            Connection conn =getConnection("c");
            java.sql.Statement stm = conn.createStatement();
          // java.sql.ResultSet sql = stm.executeQuery("select iteams.name,teams.price,order_contain_iteam.quantity from iteams,order,order_contain_iteam where `orderno`="+orderNo.getText()+",name=iteam_iteamname,order_orderno=orderno " );
            java.sql.ResultSet sql = stm.executeQuery("select * from `order_contain_iteam` where `order_orderno`="+orderNo.getText());            
                   
       jTable2.setModel(DbUtils.resultSetToTableModel(sql));
         //  jTextarea.setText(sql.getString(1));
    
        //jTextarea.setText(sql.getNString(2));
     //  
        } 
        catch (SQLException | HeadlessException e){
        }
    }
   
    public Connection getConnection(String s)
    {
        Connection con = null;
        
        try{
            if (s.equals("c"))
            
            con = DriverManager.getConnection("jdbc:mysql://localhost/myprogect","root","123");
            //else if(s.equals("a"))
            //con = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_schema","cacher","12345678");

        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        
        return con;
    }
             
public ArrayList<User> ListUsers(String ValToSearch)
    {
        ArrayList<User> usersList = new ArrayList<User>();
        
        Statement st;
        ResultSet rs;
        
        try{
            Connection con = getConnection("c");
            st = con.createStatement();
            String searchQuery = "SELECT * FROM `customer` WHERE CONCAT(`idcustomer`, `customerName`, `address`, `contactNo`) LIKE '%"+ValToSearch+"%'";
            rs = st.executeQuery(searchQuery);
            
            User user;
            
            while(rs.next())
            {
                user = new User(
                                 rs.getInt("idcustomer"),
                                 rs.getString("customerName"),
                                 rs.getString("address"),
                                 rs.getInt("contactNo")
                                );
                usersList.add(user);
            }
            
        }catch(Exception ex){
        }
        
        return usersList;
    }
 

     public void findUsers()
    {
        ArrayList<User> users = ListUsers(search.getText());
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"idcustomer","customerName","address","contactNo"});
        Object[] row = new Object[4];
        
        for(int i = 0; i < users.size(); i++)
        {
            row[0] = users.get(i).getidcustomer();
            row[1] = users.get(i).getcustomerName();
            row[2] = users.get(i).getaddress();
            row[3] = users.get(i).getcontactno();
            model.addRow(row);
        }
       jTable1.setModel(model);
       
    }
    
    
    
public void jTableClicked(String Name){
 
     if ("jTable1".equals(Name)){
  try {
            int row =jTable1.getSelectedRow();
            String tabel_klik=(jTable1.getModel().getValueAt(row, 0).toString());
            Connection conn=getConnection("c");
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet sql = stm.executeQuery("select * from customer where idcustomer='"+tabel_klik+"'");
            if(sql.next()){
                String ID = sql.getString("idcustomer");
                id.setText(ID);
                String customerName = sql.getString("customerName");
                name.setText(customerName);
                
                String Address = sql.getString("address");
                address.setText(Address);
                String contactNo = sql.getString("contactNo");
                contact.setText(contactNo); 
                 
            } 
        } catch (Exception e) {
                        
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, e);

        }        
        }else  if ("jTable2".equals(Name)){
  try {
            int row =jTable2.getSelectedRow();
            String tabel_klik=(jTable2.getModel().getValueAt(row,3).toString());
            Connection conn=getConnection("c");
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet sql = stm.executeQuery("select  * from `order_contain_iteam` where `no`='"+tabel_klik+"'");
             if(sql.next()){
                String ID = sql.getString("no");
                iteam.setText(ID);
                txtAll.setText("");
             }
        } catch (Exception e) {
                        
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, e);

        }        
        }
 

 }
 
 
 
  public void setAll(String s){
        
     String all = txtAll.getText()+s;
     txtAll.setText(all);
    
    }
  
  
  public void iteams(String name){
try {
        // TODO add your handling code here:
        
        Connection s=getConnection("c");
        String q = "INSERT INTO `order_contain_iteam`(`order_orderno`,`iteam_iteamname`)"
                + "VALUES (?,?)";
        PreparedStatement prepareStmt = s.prepareStatement(q);
        
        prepareStmt.setInt(1,Integer.parseInt(orderNo.getText()));
        
        prepareStmt.setString (2,name);
        
        prepareStmt.executeUpdate();
        GEtmun();
       // Statement stm = s.createStatement();
      //   String d=" select  `order.orderno` ,sum(`iteams.price`) form `order`,`iteams` groupe by `order.orderno` where `order.orderno`in("+orderNo.getText()+")";
        
         
        //   ResultSet sql = stm.executeQuery(d);
         /*  if(sql.next()){
                String ID = sql.getString("sum(price)");
                total.setText(ID);
               
             }*/
          GEtmun();
        s.close();
      
    } catch (SQLException ex) {
        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"the "+name+"is alrady selected " );
        
        
    }
  }
  
public void numbers(int num){
      try {
        // TODO add your handling code here:
        
     
        //to change the quantity of any iteam to 1
       setAll(num+"");
        
        Connection s=getConnection("c");
        
        String query = "UPDATE `order_contain_iteam` SET quantity=?"
                + " WHERE `no`= "+iteam.getText();
        // create the mysql insert preparedstatement
        PreparedStatement preparedStmt = s.prepareStatement(query);
        preparedStmt.setInt(1,Integer.parseInt( txtAll.getText()));
           preparedStmt.executeUpdate();
        GEtmun();
      s.close();
     
    } catch (SQLException ex) {
        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
    }
}

    /**
     * Creates new form NewJFrame
     */
    public NewJFrame() {
        initComponents();
        GetData();
         findUsers();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        name = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        contact = new javax.swing.JTextField();
        search = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        add = new javax.swing.JLabel();
        update = new javax.swing.JLabel();
        delete = new javax.swing.JLabel();
        menue = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        Blank = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        MeaPan = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        CDPan = new javax.swing.JPanel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        PizzaPan = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        HDPan = new javax.swing.JPanel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        DessPan = new javax.swing.JPanel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        SandPan = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        SausageBurger = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextarea = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        delete1 = new javax.swing.JButton();
        jLabel60 = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        orderNo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        back = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        print = new javax.swing.JButton();
        txtAll = new javax.swing.JLabel();
        iteam = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        cid = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        billno1 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1650, 1050));
        getContentPane().setLayout(new java.awt.CardLayout());

        jPanel2.setPreferredSize(new java.awt.Dimension(1650, 1050));
        jPanel2.setLayout(null);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(500, 50, 700, 640);
        jPanel2.add(name);
        name.setBounds(150, 80, 190, 30);
        jPanel2.add(address);
        address.setBounds(150, 140, 190, 30);
        jPanel2.add(contact);
        contact.setBounds(150, 200, 190, 30);

        search.setText("Search");
        search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchMouseClicked(evt);
            }
        });
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        jPanel2.add(search);
        search.setBounds(500, 10, 180, 30);

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        jPanel2.add(id);
        id.setBounds(150, 40, 190, 30);

        jLabel10.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("id:");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(100, 40, 24, 30);

        jLabel7.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Name:");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(70, 80, 52, 30);

        jLabel8.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Address:");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(50, 140, 80, 30);

        jLabel9.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Contact No:");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(20, 200, 100, 30);

        add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled-1_2.png"))); // NOI18N
        add.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                addMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                addMouseReleased(evt);
            }
        });
        jPanel2.add(add);
        add.setBounds(40, 320, 85, 40);

        update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled-1_2_1.png"))); // NOI18N
        update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                updateMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                updateMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                updateMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                updateMouseReleased(evt);
            }
        });
        update.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                updateKeyPressed(evt);
            }
        });
        jPanel2.add(update);
        update.setBounds(190, 320, 85, 40);

        delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled-1_3.png"))); // NOI18N
        delete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                deleteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                deleteMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                deleteMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                deleteMouseReleased(evt);
            }
        });
        jPanel2.add(delete);
        delete.setBounds(340, 320, 85, 40);

        menue.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled-4.png"))); // NOI18N
        menue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menueMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                menueMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                menueMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                menueMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                menueMouseReleased(evt);
            }
        });
        jPanel2.add(menue);
        menue.setBounds(190, 520, 85, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Log-Out-icon.png"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel1);
        jLabel1.setBounds(30, 550, 130, 130);
        jPanel2.add(jLabel12);
        jLabel12.setBounds(60, 420, 0, 0);

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/DDW_904932.png"))); // NOI18N
        jPanel2.add(jLabel13);
        jLabel13.setBounds(0, 0, 1650, 930);

        getContentPane().add(jPanel2, "card2");

        jPanel3.setLayout(null);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(null);

        jLabel19.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("     Cold Drinks");
        jPanel4.add(jLabel19);
        jLabel19.setBounds(1260, 70, 100, 20);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Steak-icon.png"))); // NOI18N
        jLabel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel18MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel18);
        jLabel18.setBounds(0, 0, 100, 75);

        jLabel23.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("         Meals");
        jPanel4.add(jLabel23);
        jLabel23.setBounds(0, 70, 100, 20);

        jLabel22.setBackground(new java.awt.Color(0, 0, 51));
        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Mai-Tai-icon.png"))); // NOI18N
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel22);
        jLabel22.setBounds(1280, 0, 90, 70);

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/hamburger-icon.png"))); // NOI18N
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel21);
        jLabel21.setBounds(250, 10, 90, 70);

        jLabel24.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("   Sandwiches");
        jPanel4.add(jLabel24);
        jLabel24.setBounds(250, 70, 90, 19);

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/15555764_1143637059065748_1854776652_n.png"))); // NOI18N
        jLabel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel25MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel25MouseEntered(evt);
            }
        });
        jPanel4.add(jLabel25);
        jLabel25.setBounds(490, 0, 100, 70);

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/donuts-icon.png"))); // NOI18N
        jLabel27.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel27MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel27);
        jLabel27.setBounds(750, 0, 100, 70);

        jLabel26.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("         Pizaa");
        jPanel4.add(jLabel26);
        jLabel26.setBounds(490, 70, 100, 20);

        jLabel28.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("       Dessert");
        jPanel4.add(jLabel28);
        jLabel28.setBounds(750, 70, 100, 20);

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/coffee-icon.png"))); // NOI18N
        jLabel29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel29MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel29);
        jLabel29.setBounds(1010, 0, 100, 70);

        jLabel30.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("    Hot Drinks");
        jPanel4.add(jLabel30);
        jLabel30.setBounds(1010, 70, 100, 20);

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/15682149_1150624038367050_1524882152_o.jpg"))); // NOI18N
        jPanel4.add(jLabel44);
        jLabel44.setBounds(0, 0, 1370, 100);

        jLabel47.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("Steak");
        jLabel47.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel47MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel47);
        jLabel47.setBounds(840, 0, 40, 1000);

        jPanel3.add(jPanel4);
        jPanel4.setBounds(0, 0, 1370, 100);

        jPanel7.setLayout(new java.awt.CardLayout());

        Blank.setLayout(null);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/3.jpg"))); // NOI18N
        Blank.add(jLabel14);
        jLabel14.setBounds(0, 0, 650, 550);

        jPanel7.add(Blank, "card3");

        MeaPan.setLayout(null);

        jLabel55.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setText("Steak");
        jLabel55.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel55MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel55);
        jLabel55.setBounds(150, 180, 40, 19);

        jLabel48.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("kabab");
        jLabel48.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel48MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel48);
        jLabel48.setBounds(450, 180, 39, 19);

        jLabel49.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 255, 255));
        jLabel49.setText("Rice and salad");
        jLabel49.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel49MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel49);
        jLabel49.setBounds(140, 260, 100, 19);

        jLabel56.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(255, 255, 255));
        jLabel56.setText("Cheken Mandi");
        jLabel56.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel56MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel56);
        jLabel56.setBounds(420, 260, 110, 19);

        jLabel66.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 255, 255));
        jLabel66.setText("Chicken Littles");
        jLabel66.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel66MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel66);
        jLabel66.setBounds(140, 350, 100, 19);

        jLabel83.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(255, 255, 255));
        jLabel83.setText("kabsa");
        jLabel83.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel83MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel83);
        jLabel83.setBounds(450, 350, 40, 19);

        jLabel84.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(255, 255, 255));
        jLabel84.setText("Popcorn Nuggets");
        jLabel84.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel84MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel84);
        jLabel84.setBounds(140, 430, 110, 19);

        jLabel87.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel87.setForeground(new java.awt.Color(255, 255, 255));
        jLabel87.setText("Rice and shrimps");
        jLabel87.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel87MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel87);
        jLabel87.setBounds(410, 430, 110, 19);

        jLabel88.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel88.setForeground(new java.awt.Color(255, 255, 255));
        jLabel88.setText("Meal 2 LargeSides ");
        jLabel88.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel88MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel88);
        jLabel88.setBounds(140, 500, 130, 19);

        jLabel95.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel95.setForeground(new java.awt.Color(255, 255, 255));
        jLabel95.setText("Pasta béchamel");
        jLabel95.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel95MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel95);
        jLabel95.setBounds(420, 500, 120, 20);

        jLabel50.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 255, 255));
        jLabel50.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel50MouseClicked(evt);
            }
        });
        MeaPan.add(jLabel50);
        jLabel50.setBounds(450, 290, 100, 0);

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/3.jpg"))); // NOI18N
        jLabel35.setOpaque(true);
        MeaPan.add(jLabel35);
        jLabel35.setBounds(0, 0, 650, 550);

        jPanel7.add(MeaPan, "card3");

        CDPan.setMaximumSize(new java.awt.Dimension(451, 726));
        CDPan.setMinimumSize(new java.awt.Dimension(450, 725));
        CDPan.setLayout(null);

        jLabel57.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setText("Cola");
        jLabel57.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel57MouseClicked(evt);
            }
        });
        CDPan.add(jLabel57);
        jLabel57.setBounds(190, 200, 30, 19);

        jLabel58.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setText("Lemon juice");
        jLabel58.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel58MouseClicked(evt);
            }
        });
        CDPan.add(jLabel58);
        jLabel58.setBounds(440, 200, 76, 19);

        jLabel59.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(255, 255, 255));
        jLabel59.setText("Mango juice");
        jLabel59.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel59MouseClicked(evt);
            }
        });
        CDPan.add(jLabel59);
        jLabel59.setBounds(180, 280, 80, 19);

        jLabel61.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(255, 255, 255));
        jLabel61.setText("Orange juice");
        jLabel61.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel61MouseClicked(evt);
            }
        });
        CDPan.add(jLabel61);
        jLabel61.setBounds(180, 370, 90, 19);

        jLabel62.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(255, 255, 255));
        jLabel62.setText("Strawberry Lemonade");
        jLabel62.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel62MouseClicked(evt);
            }
        });
        CDPan.add(jLabel62);
        jLabel62.setBounds(410, 370, 140, 19);

        jLabel63.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(255, 255, 255));
        jLabel63.setText("Strawberry juice");
        jLabel63.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel63MouseClicked(evt);
            }
        });
        CDPan.add(jLabel63);
        jLabel63.setBounds(170, 450, 110, 19);

        jLabel64.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 255, 255));
        jLabel64.setText("Aquafina Water");
        jLabel64.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel64MouseClicked(evt);
            }
        });
        CDPan.add(jLabel64);
        jLabel64.setBounds(440, 450, 100, 20);

        jLabel65.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(255, 255, 255));
        jLabel65.setText("Apple juice");
        jLabel65.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel65MouseClicked(evt);
            }
        });
        CDPan.add(jLabel65);
        jLabel65.setBounds(440, 280, 70, 19);

        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/3.jpg"))); // NOI18N
        jLabel40.setOpaque(true);
        CDPan.add(jLabel40);
        jLabel40.setBounds(0, 0, 650, 550);

        jPanel7.add(CDPan, "card4");

        PizzaPan.setMaximumSize(new java.awt.Dimension(451, 726));
        PizzaPan.setMinimumSize(new java.awt.Dimension(450, 725));
        PizzaPan.setLayout(null);

        jLabel67.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(255, 255, 255));
        jLabel67.setText("Vegetables Pizza");
        jLabel67.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel67MouseClicked(evt);
            }
        });
        PizzaPan.add(jLabel67);
        jLabel67.setBounds(170, 190, 100, 19);

        jLabel68.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 255, 255));
        jLabel68.setText("Tomato Pie PIZZA");
        jLabel68.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel68MouseClicked(evt);
            }
        });
        PizzaPan.add(jLabel68);
        jLabel68.setBounds(430, 190, 113, 19);

        jLabel69.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(255, 255, 255));
        jLabel69.setText("Seafood Pizza");
        jLabel69.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel69MouseClicked(evt);
            }
        });
        PizzaPan.add(jLabel69);
        jLabel69.setBounds(180, 270, 90, 19);

        jLabel70.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(255, 255, 255));
        jLabel70.setText("Sausage Pizza");
        jLabel70.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel70MouseClicked(evt);
            }
        });
        PizzaPan.add(jLabel70);
        jLabel70.setBounds(440, 270, 90, 19);

        jLabel71.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(255, 255, 255));
        jLabel71.setText("Beef Pizza");
        jLabel71.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel71MouseClicked(evt);
            }
        });
        PizzaPan.add(jLabel71);
        jLabel71.setBounds(190, 360, 70, 19);

        jLabel72.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel72.setForeground(new java.awt.Color(255, 255, 255));
        jLabel72.setText("Chicken Pizza");
        jLabel72.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel72MouseClicked(evt);
            }
        });
        PizzaPan.add(jLabel72);
        jLabel72.setBounds(440, 360, 90, 19);

        jLabel73.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel73.setForeground(new java.awt.Color(255, 255, 255));
        jLabel73.setText("Tuna Pizza");
        jLabel73.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel73MouseClicked(evt);
            }
        });
        PizzaPan.add(jLabel73);
        jLabel73.setBounds(190, 440, 70, 19);

        jLabel74.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel74.setForeground(new java.awt.Color(255, 255, 255));
        jLabel74.setText("Margreta Pizza");
        jLabel74.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel74MouseClicked(evt);
            }
        });
        PizzaPan.add(jLabel74);
        jLabel74.setBounds(440, 440, 100, 19);

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/3.jpg"))); // NOI18N
        jLabel37.setOpaque(true);
        PizzaPan.add(jLabel37);
        jLabel37.setBounds(0, 0, 650, 550);

        jPanel7.add(PizzaPan, "card5");

        HDPan.setMaximumSize(new java.awt.Dimension(451, 726));
        HDPan.setMinimumSize(new java.awt.Dimension(450, 725));
        HDPan.setLayout(null);

        jLabel75.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(255, 255, 255));
        jLabel75.setText("Tea");
        jLabel75.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel75MouseClicked(evt);
            }
        });
        jLabel75.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jLabel75KeyPressed(evt);
            }
        });
        HDPan.add(jLabel75);
        jLabel75.setBounds(190, 190, 40, 19);

        jLabel76.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(255, 255, 255));
        jLabel76.setText("Orchid");
        jLabel76.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel76MouseClicked(evt);
            }
        });
        HDPan.add(jLabel76);
        jLabel76.setBounds(450, 190, 42, 19);

        jLabel77.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(255, 255, 255));
        jLabel77.setText("coffee");
        jLabel77.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel77MouseClicked(evt);
            }
        });
        HDPan.add(jLabel77);
        jLabel77.setBounds(190, 270, 39, 19);

        jLabel78.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(255, 255, 255));
        jLabel78.setText("Latte");
        jLabel78.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel78MouseClicked(evt);
            }
        });
        HDPan.add(jLabel78);
        jLabel78.setBounds(450, 270, 40, 19);

        jLabel79.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel79.setForeground(new java.awt.Color(255, 255, 255));
        jLabel79.setText("Cappuccino");
        jLabel79.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel79MouseClicked(evt);
            }
        });
        jLabel79.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jLabel79KeyPressed(evt);
            }
        });
        HDPan.add(jLabel79);
        jLabel79.setBounds(190, 360, 80, 19);

        jLabel80.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel80.setForeground(new java.awt.Color(255, 255, 255));
        jLabel80.setText("Feverfew");
        jLabel80.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel80MouseClicked(evt);
            }
        });
        jLabel80.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jLabel80KeyPressed(evt);
            }
        });
        HDPan.add(jLabel80);
        jLabel80.setBounds(450, 360, 60, 19);

        jLabel81.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel81.setForeground(new java.awt.Color(255, 255, 255));
        jLabel81.setText("Iced Tea");
        jLabel81.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel81MouseClicked(evt);
            }
        });
        jLabel81.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jLabel81KeyPressed(evt);
            }
        });
        HDPan.add(jLabel81);
        jLabel81.setBounds(190, 440, 60, 19);

        jLabel82.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel82.setForeground(new java.awt.Color(255, 255, 255));
        jLabel82.setText("Mint");
        jLabel82.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel82MouseClicked(evt);
            }
        });
        HDPan.add(jLabel82);
        jLabel82.setBounds(460, 440, 30, 19);

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/3.jpg"))); // NOI18N
        jLabel39.setOpaque(true);
        HDPan.add(jLabel39);
        jLabel39.setBounds(0, 0, 650, 550);

        jPanel7.add(HDPan, "card6");

        DessPan.setMaximumSize(new java.awt.Dimension(451, 726));
        DessPan.setMinimumSize(new java.awt.Dimension(450, 725));
        DessPan.setLayout(null);

        jLabel85.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel85.setForeground(new java.awt.Color(255, 255, 255));
        jLabel85.setText("Apple Slices");
        jLabel85.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel85MouseClicked(evt);
            }
        });
        DessPan.add(jLabel85);
        jLabel85.setBounds(180, 200, 80, 19);

        jLabel86.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel86.setForeground(new java.awt.Color(255, 255, 255));
        jLabel86.setText("Baked Apple Pie");
        jLabel86.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel86MouseClicked(evt);
            }
        });
        DessPan.add(jLabel86);
        jLabel86.setBounds(440, 200, 104, 19);

        jLabel89.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(255, 255, 255));
        jLabel89.setText("Ice Cream");
        jLabel89.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel89MouseClicked(evt);
            }
        });
        DessPan.add(jLabel89);
        jLabel89.setBounds(180, 270, 70, 19);

        jLabel90.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel90.setForeground(new java.awt.Color(255, 255, 255));
        jLabel90.setText("Chocolate Cake");
        jLabel90.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel90MouseClicked(evt);
            }
        });
        DessPan.add(jLabel90);
        jLabel90.setBounds(440, 270, 120, 19);

        jLabel91.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel91.setForeground(new java.awt.Color(255, 255, 255));
        jLabel91.setText("with OREO Cookies");
        jLabel91.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel91MouseClicked(evt);
            }
        });
        DessPan.add(jLabel91);
        jLabel91.setBounds(160, 330, 130, 19);

        jLabel92.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel92.setForeground(new java.awt.Color(255, 255, 255));
        jLabel92.setText("With Cake");
        jLabel92.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel92MouseClicked(evt);
            }
        });
        DessPan.add(jLabel92);
        jLabel92.setBounds(450, 330, 70, 19);

        jLabel93.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel93.setForeground(new java.awt.Color(255, 255, 255));
        jLabel93.setText("Chocolate Cookie");
        jLabel93.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel93MouseClicked(evt);
            }
        });
        DessPan.add(jLabel93);
        jLabel93.setBounds(170, 390, 120, 19);

        jLabel94.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel94.setForeground(new java.awt.Color(255, 255, 255));
        jLabel94.setText("Donates");
        jLabel94.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel94MouseClicked(evt);
            }
        });
        DessPan.add(jLabel94);
        jLabel94.setBounds(460, 390, 60, 20);

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/3.jpg"))); // NOI18N
        jLabel38.setOpaque(true);
        DessPan.add(jLabel38);
        jLabel38.setBounds(0, 0, 650, 550);

        jPanel7.add(DessPan, "card7");

        SandPan.setLayout(null);

        jLabel15.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Egg Burger");
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });
        SandPan.add(jLabel15);
        jLabel15.setBounds(180, 200, 90, 19);

        jLabel16.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Filet-O-Fish");
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });
        SandPan.add(jLabel16);
        jLabel16.setBounds(440, 200, 75, 19);

        SausageBurger.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        SausageBurger.setForeground(new java.awt.Color(255, 255, 255));
        SausageBurger.setText("Sausage Burger");
        SausageBurger.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SausageBurgerMouseClicked(evt);
            }
        });
        SandPan.add(SausageBurger);
        SausageBurger.setBounds(170, 280, 110, 19);

        jLabel32.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Double Cheeseburger");
        jLabel32.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel32MouseClicked(evt);
            }
        });
        SandPan.add(jLabel32);
        jLabel32.setBounds(410, 280, 150, 19);

        jLabel33.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Big Burger");
        jLabel33.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel33MouseClicked(evt);
            }
        });
        SandPan.add(jLabel33);
        jLabel33.setBounds(180, 370, 70, 19);

        jLabel34.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Quarter Pounder Meat");
        jLabel34.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel34MouseClicked(evt);
            }
        });
        SandPan.add(jLabel34);
        jLabel34.setBounds(410, 370, 150, 19);

        jLabel41.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText(" Hamburger");
        jLabel41.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel41MouseClicked(evt);
            }
        });
        SandPan.add(jLabel41);
        jLabel41.setBounds(170, 450, 80, 19);

        jLabel42.setFont(new java.awt.Font("Century751 BT", 0, 14)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText(" ChickenMeatBurger");
        jLabel42.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel42MouseClicked(evt);
            }
        });
        SandPan.add(jLabel42);
        jLabel42.setBounds(410, 450, 130, 19);

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/3.jpg"))); // NOI18N
        jLabel36.setOpaque(true);
        SandPan.add(jLabel36);
        jLabel36.setBounds(0, 0, 650, 550);

        jPanel7.add(SandPan, "card8");

        jPanel3.add(jPanel7);
        jPanel7.setBounds(690, 120, 650, 550);

        jPanel9.setLayout(null);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable2);

        jPanel9.add(jScrollPane3);
        jScrollPane3.setBounds(70, 80, 510, 160);

        jTextarea.setColumns(20);
        jTextarea.setRows(5);
        jTextarea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextareaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTextarea);

        jPanel9.add(jScrollPane2);
        jScrollPane2.setBounds(70, 80, 510, 160);

        jButton1.setText("1");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton1);
        jButton1.setBounds(200, 270, 70, 40);

        jButton2.setText("2");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jButton2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton2KeyPressed(evt);
            }
        });
        jPanel9.add(jButton2);
        jButton2.setBounds(290, 270, 70, 40);

        jButton3.setText("3");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jButton3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton3KeyPressed(evt);
            }
        });
        jPanel9.add(jButton3);
        jButton3.setBounds(380, 270, 70, 40);

        jButton4.setText("4");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton4);
        jButton4.setBounds(200, 330, 70, 40);

        jButton5.setText("5");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton5);
        jButton5.setBounds(290, 330, 70, 40);

        jButton6.setText("6");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton6);
        jButton6.setBounds(380, 330, 70, 40);

        jButton7.setText("7");
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton7MouseClicked(evt);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton7);
        jButton7.setBounds(200, 390, 70, 40);

        jButton8.setText("8");
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton8MouseClicked(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton8);
        jButton8.setBounds(290, 390, 70, 40);

        jButton9.setText("9");
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton9MouseClicked(evt);
            }
        });
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton9);
        jButton9.setBounds(380, 390, 70, 40);

        jButton10.setText("0");
        jButton10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton10MouseClicked(evt);
            }
        });
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton10);
        jButton10.setBounds(290, 450, 70, 40);

        delete1.setText("Delete");
        delete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete1ActionPerformed(evt);
            }
        });
        jPanel9.add(delete1);
        delete1.setBounds(200, 450, 70, 40);
        jPanel9.add(jLabel60);
        jLabel60.setBounds(190, 250, 270, 240);

        total.setForeground(new java.awt.Color(255, 255, 255));
        jPanel9.add(total);
        total.setBounds(420, 60, 60, 20);

        orderNo.setForeground(new java.awt.Color(255, 255, 255));
        jPanel9.add(orderNo);
        orderNo.setBounds(150, 60, 40, 20);

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("total is :");
        jPanel9.add(jLabel3);
        jLabel3.setBounds(360, 60, 60, 20);

        back.setIcon(new javax.swing.ImageIcon("C:\\Users\\abdelrhman\\Desktop\\back-icon.png")); // NOI18N
        back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backMouseClicked(evt);
            }
        });
        jPanel9.add(back);
        back.setBounds(70, 390, 80, 100);

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("orderNo :");
        jPanel9.add(jLabel11);
        jLabel11.setBounds(89, 60, 50, 14);

        print.setText("print");
        print.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                printMouseClicked(evt);
            }
        });
        print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printActionPerformed(evt);
            }
        });
        jPanel9.add(print);
        print.setBounds(380, 450, 70, 40);
        jPanel9.add(txtAll);
        txtAll.setBounds(80, 260, 90, 150);
        jPanel9.add(iteam);
        iteam.setBounds(80, 310, 110, 50);

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/33.jpg"))); // NOI18N
        jPanel9.add(jLabel17);
        jLabel17.setBounds(0, 0, 650, 550);
        jPanel9.add(cid);
        cid.setBounds(520, 280, 40, 30);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable3);

        jPanel9.add(jScrollPane4);
        jScrollPane4.setBounds(70, 80, 510, 160);

        billno1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                billno1MouseClicked(evt);
            }
        });
        jPanel9.add(billno1);
        billno1.setBounds(70, 390, 80, 100);

        jPanel3.add(jPanel9);
        jPanel9.setBounds(30, 120, 650, 550);

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled-1.jpg"))); // NOI18N
        jPanel3.add(jLabel43);
        jLabel43.setBounds(0, 100, 1370, 620);

        getContentPane().add(jPanel3, "card4");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-2_2.png"));
        add.setIcon(II);
    }//GEN-LAST:event_addMouseEntered

    private void addMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-1_2.png"));
        add.setIcon(II);
    }//GEN-LAST:event_addMouseExited

    private void addMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-3_2.png"));
        add.setIcon(II);
    }//GEN-LAST:event_addMousePressed

    private void addMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-2_2.png"));
        add.setIcon(II);
    }//GEN-LAST:event_addMouseReleased

    private void updateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-2_2_1.png"));
        update.setIcon(II);
    }//GEN-LAST:event_updateMouseEntered

    private void updateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-1_2_1.png"));
        update.setIcon(II);
    }//GEN-LAST:event_updateMouseExited

    private void updateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-3_2_1.png"));
        update.setIcon(II);
    }//GEN-LAST:event_updateMousePressed

    private void updateMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-2_2_1.png"));
        update.setIcon(II);
    }//GEN-LAST:event_updateMouseReleased

    private void deleteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-2_3.png"));
        delete.setIcon(II);
    }//GEN-LAST:event_deleteMouseEntered

    private void deleteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-1_3.png"));
        delete.setIcon(II);
    }//GEN-LAST:event_deleteMouseExited

    private void deleteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-3_3.png"));
        delete.setIcon(II);
    }//GEN-LAST:event_deleteMousePressed

    private void deleteMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images/Untitled-2_3.png"));
        delete.setIcon(II);
    }//GEN-LAST:event_deleteMouseReleased

    private void menueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menueMouseClicked
        // TODO add your handling code here:
 Statement st;
        ResultSet rs;
    try {
        // TODO add your handling code here:
          Connection conn =  getConnection("c");
        
        
        String query = "INSERT INTO `order` (`state`) VALUES(?)";
        
        
          
     PreparedStatement pst = conn.prepareStatement(query);
     
         pst.setString(1, "new");
           
      pst.executeUpdate();
      
        st = conn.createStatement();
      String sql="select orderno from `order`";
          
            
              rs = st.executeQuery(sql);
              
             String s="";  
        while(rs.next()){
       s= rs.getInt("orderno")+"";
        
            
        
        }
       orderNo.setText(s);
       cid.setText(id.getText());
       GetData();
        JOptionPane.showMessageDialog(null, orderNo.getText()
        );
        
        //jPanel1.setVisible(false);
        jPanel2.setVisible(false);
        jPanel3.setVisible(true);
        MeaPan.setVisible(false);
        SandPan.setVisible(false);
        PizzaPan.setVisible(false);
        DessPan.setVisible(false);
        HDPan.setVisible(false);
        CDPan.setVisible(false);
    } catch (SQLException ex) {
        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
    }
        
        
    }//GEN-LAST:event_menueMouseClicked

    private void menueMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menueMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("Images/Untitled-4_2.png"));
        menue.setIcon(II);
    }//GEN-LAST:event_menueMouseEntered

    private void menueMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menueMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("Images/Untitled-4.png"));
        menue.setIcon(II);
    }//GEN-LAST:event_menueMouseExited

    private void menueMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menueMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("Images/Untitled-4_3.png"));
        menue.setIcon(II);
    }//GEN-LAST:event_menueMousePressed

    private void menueMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menueMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("Images/Untitled-4.png"));
        menue.setIcon(II);
    }//GEN-LAST:event_menueMouseReleased

    private void jLabel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel18MouseClicked
        // TODO add your handling code here:
        MeaPan.setVisible(true);
        SandPan.setVisible(false);
        PizzaPan.setVisible(false);
        DessPan.setVisible(false);
        HDPan.setVisible(false);
        CDPan.setVisible(false);
        Blank.setVisible(false);
    }//GEN-LAST:event_jLabel18MouseClicked

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
        // TODO add your handling code here:
        MeaPan.setVisible(false);
        SandPan.setVisible(false);
        PizzaPan.setVisible(false);
        DessPan.setVisible(false);
        HDPan.setVisible(false);
        CDPan.setVisible(true);
        Blank.setVisible(false);
    }//GEN-LAST:event_jLabel22MouseClicked

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
        MeaPan.setVisible(false);
        SandPan.setVisible(true);
        PizzaPan.setVisible(false);
        DessPan.setVisible(false);
        HDPan.setVisible(false);
        CDPan.setVisible(false);
        Blank.setVisible(false);
    }//GEN-LAST:event_jLabel21MouseClicked

    private void jLabel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MouseClicked
        // TODO add your handling code here:
        MeaPan.setVisible(false);
        SandPan.setVisible(false);
        PizzaPan.setVisible(true);
        DessPan.setVisible(false);
        HDPan.setVisible(false);
        Blank.setVisible(false);
    }//GEN-LAST:event_jLabel25MouseClicked

    private void jLabel25MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MouseEntered
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jLabel25MouseEntered

    private void jLabel27MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel27MouseClicked
        // TODO add your handling code here:
        MeaPan.setVisible(false);
        SandPan.setVisible(false);
        PizzaPan.setVisible(false);
        DessPan.setVisible(true);
        HDPan.setVisible(false);
        CDPan.setVisible(false);
        Blank.setVisible(false);
    }//GEN-LAST:event_jLabel27MouseClicked

    private void jLabel29MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel29MouseClicked
        // TODO add your handling code here:
        MeaPan.setVisible(false);
        SandPan.setVisible(false);
        PizzaPan.setVisible(false);
        DessPan.setVisible(false);
        HDPan.setVisible(true);
        CDPan.setVisible(false);
        Blank.setVisible(false);
    }//GEN-LAST:event_jLabel29MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
   
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
     
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
      
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
      
    }//GEN-LAST:event_jButton10ActionPerformed


    private void printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printActionPerformed
        // TODO add your handling code here:
        
        
        MessageFormat header =new MessageFormat("print");
        MessageFormat footer =new MessageFormat("page{0,number,integer}");

        try{
        
        jTable2.print(JTable.PrintMode.NORMAL, header, footer);
        
        }
        
        catch(java.awt.print.PrinterException e){
        
          System.err.format("can not print %s%n", e.getMessage());
        }
        
    }//GEN-LAST:event_printActionPerformed

    private void jLabel47MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel47MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel47.getText());
     
    }//GEN-LAST:event_jLabel47MouseClicked

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void addMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addMouseClicked
        // TODO add your handling code here:
        String Name = name.getText();
     String Address = address.getText();
     String Contact = contact.getText();
    
 
     
       
         try {
             Connection s=getConnection("c");
         
            if((!"".equals(id.getText()))&&(( !"".equals(Contact))||(!"".equals(Name)))){
                    
             String query = "INSERT INTO `customer`(`idcustomer`,`customerName`, `address`, `contactNo`) "
              + "VALUES (?,?,?,?)";
            PreparedStatement stat=s.prepareStatement(query);
            int ID = Integer.parseInt(id.getText());
             stat.setInt(1, ID);
            
            stat.setString(2, Name);

            stat.setString(3, Address);

            stat.setString(4, Contact);
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
            }
            else if("".equals(id.getText())){
                    
             String query = "INSERT INTO `customer`(`customerName`, `address`, `contactNo`) "
              + "VALUES (?,?,?)";
             //String d="select idcustomer from customer ";
            PreparedStatement stat=s.prepareStatement(query);
                
            stat.setString(1, Name);

            stat.setString(2, Address);

            stat.setString(3, Contact);
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
                        JOptionPane.showMessageDialog(null, " id is outo incrment");

            }
           else
                JOptionPane.showMessageDialog(null, " pleas fill name or contact");
            
         GetData();
             
         s.close();
            }
            


            
            
        catch (SQLException ex) {
            
            
            if (("".equals(Address)) ){
                      JOptionPane.showMessageDialog(null, "address is empty");  

            
            }
            
            
            
            else if(( "".equals(Contact))&&("".equals(Name))){
            
            JOptionPane.showMessageDialog(null, "address is contact and name are empty");
            }
            
          
           else
        JOptionPane.showMessageDialog(null, "Duplicated entry change id");  
        
        }
         
        
        
        
        
        
    }//GEN-LAST:event_addMouseClicked

    private void deleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseClicked
        // TODO add your handling code here:
         try { // hapus data
            String sql ="delete from customer where idcustomer='"+id.getText()+"'";
            Connection conn =  getConnection("c");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Data akan dihapus?");
            
            
            
            id.setText("");
            name.setText("");
            address.setText("");
            contact.setText("");
             GetData();
        } catch (SQLException | HeadlessException e){
                    JOptionPane.showMessageDialog(null, "Delete fail");             

            
        }
       
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }//GEN-LAST:event_deleteMouseClicked

    private void updateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_updateKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateKeyPressed

    private void updateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseClicked
        // TODO add your handling code here:
        try {
           Connection s=getConnection("c");

            String Address = address.getText();
            String contactNo = contact.getText();
             
            String Name = name.getText();
       
      String query = "UPDATE customer SET customerName=? ,address=? ,contactNo=?"
                + " WHERE `idcustomer` = "+id.getText();
        // create the mysql insert preparedstatement
      PreparedStatement preparedStmt = s.prepareStatement(query);
      preparedStmt.setString (1, Name);
      
      preparedStmt.setString(3,contactNo);
      
      preparedStmt.setString(2,Address);
      
      
      preparedStmt.executeUpdate();
      GetData();
      s.close();
      
        } catch (SQLException ex) { 
        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
    } 
    }//GEN-LAST:event_updateMouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        
        
        
        
           jTableClicked("jTable1");
    }//GEN-LAST:event_jTable1MouseClicked

    private void searchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchMouseClicked
        // TODO add your handling code here:
        
            search.setText("");
        
    }//GEN-LAST:event_searchMouseClicked

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
        
        
            GetData();
        findUsers();
        
    }//GEN-LAST:event_searchActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
        
         numbers(1);
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton2KeyPressed
        // TODO add your handling code here:
        
       
    }//GEN-LAST:event_jButton2KeyPressed

    private void jButton3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton3KeyPressed
        // TODO add your handling code here:
        
     
    }//GEN-LAST:event_jButton3KeyPressed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        // TODO add your handling code here:
        
          numbers(2);
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        // TODO add your handling code here:
          numbers(3);
    }//GEN-LAST:event_jButton3MouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
        // TODO add your handling code here:
       iteams(jLabel15.getText());
    }//GEN-LAST:event_jLabel15MouseClicked

    private void SausageBurgerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SausageBurgerMouseClicked
        // TODO add your handling code here:
        iteams(SausageBurger.getText());
    }//GEN-LAST:event_SausageBurgerMouseClicked

    private void jLabel50MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel50MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel50.getText());
    }//GEN-LAST:event_jLabel50MouseClicked

    private void jLabel57MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel57MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel57.getText());
    }//GEN-LAST:event_jLabel57MouseClicked

    private void jLabel59MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel59MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel59.getText());
    }//GEN-LAST:event_jLabel59MouseClicked

    private void jLabel61MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel61MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel61.getText());
    }//GEN-LAST:event_jLabel61MouseClicked

    private void jLabel63MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel63MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel63.getText());
    }//GEN-LAST:event_jLabel63MouseClicked

    private void jLabel64MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel64MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel64.getText());
        
    }//GEN-LAST:event_jLabel64MouseClicked

    private void jLabel62MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel62MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel62.getText());
    }//GEN-LAST:event_jLabel62MouseClicked

    private void jLabel65MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel65MouseClicked
        // TODO add your handling code here:
        iteams(jLabel65.getText());
    }//GEN-LAST:event_jLabel65MouseClicked

    private void jLabel58MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel58MouseClicked
        // TODO add your handling code here:
        iteams(jLabel58.getText());
    }//GEN-LAST:event_jLabel58MouseClicked

    private void jLabel67MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel67MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel67.getText());
    }//GEN-LAST:event_jLabel67MouseClicked

    private void jLabel69MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel69MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel69.getText());
    }//GEN-LAST:event_jLabel69MouseClicked

    private void jLabel71MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel71MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel71.getText());
    }//GEN-LAST:event_jLabel71MouseClicked

    private void jLabel73MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel73MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel73.getText());
    }//GEN-LAST:event_jLabel73MouseClicked

    private void jLabel74MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel74MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel74.getText());
    }//GEN-LAST:event_jLabel74MouseClicked

    private void jLabel72MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel72MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel72.getText());
    }//GEN-LAST:event_jLabel72MouseClicked

    private void jLabel70MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel70MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel70.getText());
    }//GEN-LAST:event_jLabel70MouseClicked

    private void jLabel68MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel68MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel68.getText());
    }//GEN-LAST:event_jLabel68MouseClicked

    private void jLabel75KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jLabel75KeyPressed
        // TODO add your handling code here:
        
       
    }//GEN-LAST:event_jLabel75KeyPressed

    private void jLabel77MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel77MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel77.getText());
    }//GEN-LAST:event_jLabel77MouseClicked

    private void jLabel79KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jLabel79KeyPressed
        // TODO add your handling code here:
        
       
    }//GEN-LAST:event_jLabel79KeyPressed

    private void jLabel81KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jLabel81KeyPressed
        // TODO add your handling code here:
         
       
    }//GEN-LAST:event_jLabel81KeyPressed

    private void jLabel82MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel82MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel82.getText());
    }//GEN-LAST:event_jLabel82MouseClicked

    private void jLabel80KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jLabel80KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel80KeyPressed

    private void jLabel80MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel80MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel80.getText());
    }//GEN-LAST:event_jLabel80MouseClicked

    private void jLabel78MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel78MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel78.getText());
    }//GEN-LAST:event_jLabel78MouseClicked

    private void jLabel76MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel76MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel76.getText());
    }//GEN-LAST:event_jLabel76MouseClicked

    private void jLabel85MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel85MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel85.getText());
    }//GEN-LAST:event_jLabel85MouseClicked

    private void jLabel89MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel89MouseClicked
        // TODO add your handling code here:
        iteams(jLabel89.getText());
    }//GEN-LAST:event_jLabel89MouseClicked

    private void jLabel91MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel91MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel91.getText());
    }//GEN-LAST:event_jLabel91MouseClicked

    private void jLabel93MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel93MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel93.getText());
    }//GEN-LAST:event_jLabel93MouseClicked

    private void jLabel94MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel94MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel94.getText());
    }//GEN-LAST:event_jLabel94MouseClicked

    private void jLabel92MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel92MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel92.getText());
    }//GEN-LAST:event_jLabel92MouseClicked

    private void jLabel90MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel90MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel90.getText());
    }//GEN-LAST:event_jLabel90MouseClicked

    private void jLabel86MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel86MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel86.getText());
        
    }//GEN-LAST:event_jLabel86MouseClicked

    private void jLabel33MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel33MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel33.getText());
    }//GEN-LAST:event_jLabel33MouseClicked

    private void jLabel41MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel41MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel41.getText());
    }//GEN-LAST:event_jLabel41MouseClicked

    private void jLabel42MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel42MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel42.getText());
    }//GEN-LAST:event_jLabel42MouseClicked

    private void jLabel34MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel34MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel34.getText());
    }//GEN-LAST:event_jLabel34MouseClicked

    private void jLabel32MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel32MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel32.getText());
    }//GEN-LAST:event_jLabel32MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel16.getText());
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        // TODO add your handling code here:
         numbers(4);
    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        // TODO add your handling code here:
        
           numbers(5);
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
        // TODO add your handling code here:
        
           numbers(6);
    }//GEN-LAST:event_jButton6MouseClicked

    private void jButton7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseClicked
        // TODO add your handling code here:
        
           numbers(7);
    }//GEN-LAST:event_jButton7MouseClicked

    private void jButton8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseClicked
        // TODO add your handling code here:
        
           numbers(8);
    }//GEN-LAST:event_jButton8MouseClicked

    private void jButton9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseClicked
        // TODO add your handling code here:
        
           numbers(9);
    }//GEN-LAST:event_jButton9MouseClicked

    private void jButton10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseClicked
        // TODO add your handling code here:
        
           numbers(0);
    }//GEN-LAST:event_jButton10MouseClicked

    private void jTextareaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextareaMouseClicked
        // TODO add your handling code here:
        
        
        
    }//GEN-LAST:event_jTextareaMouseClicked

    private void jLabel81MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel81MouseClicked
        // TODO add your handling code here:
        
         iteams(jLabel81.getText());
    }//GEN-LAST:event_jLabel81MouseClicked

    private void jLabel79MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel79MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel79.getText());
    }//GEN-LAST:event_jLabel79MouseClicked

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        
        
        jTableClicked("jTable2");
        
        
    }//GEN-LAST:event_jTable2MouseClicked

    private void jLabel55MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel55MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel55.getText());
    }//GEN-LAST:event_jLabel55MouseClicked

    private void jLabel48MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel48MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel48.getText());
    }//GEN-LAST:event_jLabel48MouseClicked

    private void jLabel49MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel49MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel49.getText());
    }//GEN-LAST:event_jLabel49MouseClicked

    private void jLabel56MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel56MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel56.getText());
    }//GEN-LAST:event_jLabel56MouseClicked

    private void jLabel66MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel66MouseClicked
        // TODO add your handling code here:
        iteams(jLabel66.getText());
    }//GEN-LAST:event_jLabel66MouseClicked

    private void jLabel83MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel83MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel83.getText());
    }//GEN-LAST:event_jLabel83MouseClicked

    private void jLabel87MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel87MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel87.getText());
    }//GEN-LAST:event_jLabel87MouseClicked

    private void jLabel88MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel88MouseClicked
        // TODO add your handling code here:
        
        
        iteams(jLabel88.getText());
    }//GEN-LAST:event_jLabel88MouseClicked

    private void jLabel95MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel95MouseClicked
        // TODO add your handling code here:
        
        iteams(jLabel95.getText());
    }//GEN-LAST:event_jLabel95MouseClicked

    private void jLabel84MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel84MouseClicked
        // TODO add your handling code here:
         iteams(jLabel84.getText());
    }//GEN-LAST:event_jLabel84MouseClicked

    private void jLabel75MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel75MouseClicked
        // TODO add your handling code here:
        
         iteams(jLabel75.getText());
    }//GEN-LAST:event_jLabel75MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        jPanel2.setVisible(false);
        
         NewJFrame_2 y = new NewJFrame_2();
        y.setVisible(true);
             dispose();
    
          
    }//GEN-LAST:event_jLabel1MouseClicked

    private void backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backMouseClicked
        // TODO add your handling code here:
        jPanel3.setVisible(false);
        jPanel2.setVisible(true);
        
        
    }//GEN-LAST:event_backMouseClicked

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable3MouseClicked

    private void printMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printMouseClicked
         try {
             
             
             // TODO add your handling code here:
            
             Connection s=getConnection("c");
        String q = "INSERT INTO `bill`(`brachname`)"
                + "VALUES (?)";
        PreparedStatement prepareStmt = s.prepareStatement(q);
        
        prepareStmt.setString (1,"Tanta brache");
        
        
        
        
        prepareStmt.executeUpdate();
        
        
        
        
       /* String g = "INSERT INTO `customer_pay_bill`(`bill_billNo`,`customer_idcustomer`)"
                + "VALUES (?,?)";
        PreparedStatement Stmt = s.prepareStatement(g);
        
       Stmt.setString (1,billno1.getText());
          Stmt.setString (2,id.getText());
        
        
        
        Stmt.executeUpdate();
        */
       /* 
        Statement stm = s.createStatement();
           ResultSet sql = stm.executeQuery("select * from customer");
             jTable3.setModel(DbUtils.resultSetToTableModel(sql));
             
             */
      
             
         } catch (SQLException ex) {
             Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
         }
        
        
        
    }//GEN-LAST:event_printMouseClicked

    private void delete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete1ActionPerformed
        // TODO add your handling code here:
        try { // hapus data
            String sql ="delete from order_contain_iteam  where no ='"+iteam.getText()+"'";
            Connection conn =  getConnection("c");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Delete?");
            
            
            
       
             GEtmun();
        } catch (SQLException | HeadlessException e){
                    JOptionPane.showMessageDialog(null, "Delete fail");             

            
        }
       
    
        
        
    }//GEN-LAST:event_delete1ActionPerformed

    private void billno1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_billno1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_billno1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Blank;
    private javax.swing.JPanel CDPan;
    private javax.swing.JPanel DessPan;
    private javax.swing.JPanel HDPan;
    private javax.swing.JPanel MeaPan;
    private javax.swing.JPanel PizzaPan;
    private javax.swing.JPanel SandPan;
    private javax.swing.JLabel SausageBurger;
    private javax.swing.JLabel add;
    private javax.swing.JTextField address;
    private javax.swing.JLabel back;
    private javax.swing.JLabel billno1;
    private javax.swing.JLabel cid;
    private javax.swing.JTextField contact;
    private javax.swing.JLabel delete;
    private javax.swing.JButton delete1;
    private javax.swing.JTextField id;
    private javax.swing.JLabel iteam;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextArea jTextarea;
    private javax.swing.JLabel menue;
    private javax.swing.JTextField name;
    private javax.swing.JLabel orderNo;
    private javax.swing.JButton print;
    private javax.swing.JTextField search;
    private javax.swing.JLabel total;
    private javax.swing.JLabel txtAll;
    private javax.swing.JLabel update;
    // End of variables declaration//GEN-END:variables
}
