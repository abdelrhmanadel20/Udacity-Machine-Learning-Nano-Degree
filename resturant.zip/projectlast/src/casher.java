public class casher {
    
    private int id;
    private String address;
    private String name;
    private int contact;
      private int salary;
    
    public casher(int idcasher,String name,String address,int contactno,int salary)
    {
        this.id = idcasher;
        this.name = name;
        this.address = address;
        this.contact = contactno;
          this.salary = salary;
    }
    
    public int getidcasher()
    {
        return id;
    }
     public int getsalarycasher()
    {
        return salary;
    }
    
    public String getcasherName()
    {
        return name;
    }
    
    public String getcasheraddress()
    {
        return address;
    }
    
    public int getcashercontactno()
    {
        return contact;
    }
}
