
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Abd Elrhman Elattar
 */
public class NewJFrame_1 extends javax.swing.JFrame {
    
     public Connection getConnection(String s)
    {
        Connection con = null;
        
        try{
            if (s.equals("c"))
            
            con = DriverManager.getConnection("jdbc:mysql://localhost/myprogect","root","123");
            

        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        
        return con;
    }
 public void GetData(String type){ // menampilkan data dari database
        try {
            Connection conn =getConnection("c");
            java.sql.Statement stm = conn.createStatement();
            if(type=="casher"){
            
            java.sql.ResultSet sql = stm.executeQuery("select * from casher");
            ctable.setModel(DbUtils.resultSetToTableModel(sql));}
            else if(type=="cheff"){
            
            java.sql.ResultSet sql = stm.executeQuery("select * from cheff");
            shtable.setModel(DbUtils.resultSetToTableModel(sql));}
            else if(type=="waiter"){
            
            java.sql.ResultSet sql = stm.executeQuery("select * from waiter");
            wtable.setModel(DbUtils.resultSetToTableModel(sql));}
            else if(type=="plate"){
            
            java.sql.ResultSet sql = stm.executeQuery("select * from iteams");
            ptable.setModel(DbUtils.resultSetToTableModel(sql));}
        }
        catch (SQLException | HeadlessException e){
        }
    }
    public ArrayList<casher> Listcasher(String ValToSearch)
    { // methodes s=new methodes();
        ArrayList<casher> casherlist = new ArrayList<casher>();
        
        Statement st;
        ResultSet rs;
        
        try{
            Connection con = getConnection("c");
            st = con.createStatement();
            String searchQuery = "SELECT * FROM `casher` WHERE CONCAT(`casherid`,`cashername`,`address`,`contactno`,`salary`) LIKE '%"+ValToSearch+"%'";
            rs = st.executeQuery(searchQuery);
            
            casher Casher;
            
            while(rs.next())
            {
                Casher = new casher(
                                    rs.getInt("casherid"),
                                    rs.getString("cashername"),
                                    rs.getString("address"),
                                    rs.getInt("contactno"),
                                    rs.getInt("salary")
                                );
                casherlist.add(Casher);
            }
            
        }catch(Exception ex){
        }
        
        return casherlist;
    }
   
     public void findCashers()
    {
        ArrayList<casher> Cashers = Listcasher(csearch.getText());
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"casherid","cashername","address","contactno","salary"});
        Object[] row = new Object[5];
        
        for(int i = 0; i < Cashers.size(); i++)
        {
            row[0] = Cashers.get(i).getidcasher();
            row[1] = Cashers.get(i).getcasherName();
            row[2] = Cashers.get(i).getcasheraddress();
            row[3] = Cashers.get(i).getcashercontactno();
            row[4] = Cashers.get(i).getsalarycasher();
            model.addRow(row);
        }
       ctable.setModel(model);
       
    }
     
   public ArrayList<waiter> Listwaiter(String ValToSearch)
    { // methodes s=new methodes();
        ArrayList<waiter> waiterlist = new ArrayList<waiter>();
        
        Statement st;
        ResultSet rs;
        
        try{
            Connection con = getConnection("c");
            st = con.createStatement();
            String searchQuery = "SELECT * FROM `waiter` WHERE CONCAT(`idwaiter`,`waitername`,`address`,`contactno`,`salary`) LIKE '%"+ValToSearch+"%'";
            rs = st.executeQuery(searchQuery);
            
            waiter Waiter;
            
            while(rs.next())
            {
                Waiter = new waiter(
                                 rs.getInt("idwaiter"),
                                 rs.getString("waitername"),
                                 rs.getString("address"),
                                 rs.getInt("contactno"),
                                 rs.getInt("salary")
                                );
                waiterlist.add(Waiter);
            }
            
        }catch(Exception ex){
        }
        
        return waiterlist;
    }
       
      public void findwaiter()
    {
        ArrayList<waiter> Waiter = Listwaiter(wsearch.getText());
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"waiterid","waitername","address","contactno","salary"});
        Object[] row = new Object[5];
        
        for(int i = 0; i < Waiter.size(); i++)
        {
            row[0] = Waiter.get(i).getidwaiter();
            row[1] = Waiter.get(i).getwaiterName();
            row[2] = Waiter.get(i).getwaiteraddress();
            row[3] = Waiter.get(i).getwaitercontactno();
            row[4] = Waiter.get(i).getsalarywaiter();
            model.addRow(row);
        }
       wtable.setModel(model);
       
    }
      
      
      
      public ArrayList<cheff> Listcheff(String ValToSearch)
    { // methodes s=new methodes();
        ArrayList<cheff> chefflist = new ArrayList<cheff>();
        
        Statement st;
        ResultSet rs;
        
        try{
            Connection con = getConnection("c");
            st = con.createStatement();
            String searchQuery = "SELECT * FROM `waiter` WHERE CONCAT(`idwaiter`,`waitername`,`address`,`contactno`,`salary`) LIKE '%"+ValToSearch+"%'";
            rs = st.executeQuery(searchQuery);
            
            cheff Cheff;
            
            while(rs.next())
            {
                Cheff = new cheff(
                                 rs.getInt("idwaiter"),
                                 rs.getString("waitername"),
                                 rs.getString("address"),
                                 rs.getInt("contactno"),
                                 rs.getInt("salary")
                                );
                chefflist.add(Cheff);
            }
            
        }catch(Exception ex){
        }
        
        return chefflist;
    }
      
      
       public void findcheff()
    {
        ArrayList<cheff> Cheff = Listcheff(shsearch.getText());
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"waiterid","waitername","address","contactno","salary"});
        Object[] row = new Object[5];
        
        for(int i = 0; i < Cheff.size(); i++)
        {
            row[0] = Cheff.get(i).getidcheff();
            row[1] = Cheff.get(i).getcheffName();
            row[2] = Cheff.get(i).getcheffaddress();
            row[3] = Cheff.get(i).getcheffcontactno();
            row[4] = Cheff.get(i).getsalarycheff();
            model.addRow(row);
        }
       shtable.setModel(model);
       
    }
     
public void jTableClicked(String Name){
 
     if ("ctable".equals(Name)){
  try { 
            int row =ctable.getSelectedRow();
            String tabel_klik=(ctable.getModel().getValueAt(row, 0).toString());
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/myprogect" ,"root" ,"123" );
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet sql = stm.executeQuery("select * from casher where casherid='"+tabel_klik+"'");
            if(sql.next()){
                  String ID = sql.getString("casherid");
                casherid.setText(ID);
                String name = sql.getString("cashername");
                cname.setText(Name);
                
                String Address = sql.getString("address");
               casheraddress.setText(Address);
                String contactNo = sql.getString("contactno");
                ccontact.setText(contactNo);
                      String salary = sql.getString("salary");
                csalary.setText(salary);
            
                 
                 
            } 
        } catch (Exception e) {
                        
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, e);

        }        
        }else  if ("wtable".equals(Name)){
  try {
     int row =wtable.getSelectedRow();
            String tabel_klik=(wtable.getModel().getValueAt(row, 0).toString());
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/myprogect" ,"root" ,"123" );
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet sql = stm.executeQuery("select * from waiter where idwaiter='"+tabel_klik+"'");
            if(sql.next()){
                String ID = sql.getString("idwaiter");
                wid.setText(ID);
                String name = sql.getString("waitername");
                wname.setText(Name);
                
                String Address = sql.getString("address");
               waddress.setText(Address);
                String contactNo = sql.getString("contactno");
                wcontact.setText(contactNo);
                      String salary = sql.getString("salary");
                wsalary.setText(salary);
            
             }
        } catch (Exception e) {
                        
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, e);

        }        
        
 }else  if ("shtable".equals(Name)){
  try {
     int row =shtable.getSelectedRow();
            String tabel_klik=(shtable.getModel().getValueAt(row, 0).toString());
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/myprogect" ,"root" ,"123" );
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet sql = stm.executeQuery("select * from cheff where idcheff='"+tabel_klik+"'");
            if(sql.next()){
                String ID = sql.getString("idcheff");
                shid1.setText(ID);
                String name = sql.getString("cheffname");
                shname.setText(Name);
                
                String Address = sql.getString("address");
               shaddress.setText(Address);
                String contactNo = sql.getString("contactno");
                shcontact.setText(contactNo);
                      String salary = sql.getString("salary");
                shsalary.setText(salary);
            
         
             }
        } catch (Exception e) {
                        
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, e);

        } }
  else  if ("plate".equals(Name)){
  try {
     int row =ptable.getSelectedRow();
            String tabel_klik=(ptable.getModel().getValueAt(row, 0).toString());
            Connection conn=getConnection("c");
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet sql = stm.executeQuery("select * from iteams where iteamNo='"+tabel_klik+"'");
            if(sql.next()){
                String ID = sql.getString("iteamNo");
                plid.setText(ID);
                String name = sql.getString("name");
                pname.setText(name);
                
                String price = sql.getString("price");
               pprice.setText(price);
                String description = sql.getString("description");
                pdescription.setText(description);
                    
            
         
             }
        } catch (Exception e) {
                        
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, e);

        }       
        
}
}

 
    /**
     * Creates new form NewJFrame
     */
    public NewJFrame_1() {
        initComponents();
        findCashers();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Metro = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Statistics = new javax.swing.JPanel();
        Chart = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        Cashier = new javax.swing.JPanel();
        cdelete = new javax.swing.JLabel();
        cupdate = new javax.swing.JLabel();
        casheraddress = new javax.swing.JTextField();
        cname = new javax.swing.JTextField();
        csearch = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        ctable = new javax.swing.JTable();
        ccontact = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        cadd = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        casherid = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        csalary = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        Chef = new javax.swing.JPanel();
        shdelete = new javax.swing.JLabel();
        shupdate = new javax.swing.JLabel();
        shaddress = new javax.swing.JTextField();
        shname = new javax.swing.JTextField();
        shsearch = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        shtable = new javax.swing.JTable();
        shcontact = new javax.swing.JTextField();
        shid1 = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        shsalary = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        shadd = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        Waiter = new javax.swing.JPanel();
        wdelete = new javax.swing.JLabel();
        wupdate = new javax.swing.JLabel();
        waddress = new javax.swing.JTextField();
        wname = new javax.swing.JTextField();
        wsearch = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        wtable = new javax.swing.JTable();
        wcontact = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        wadd = new javax.swing.JLabel();
        wid = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        wsalary = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        newplate = new javax.swing.JPanel();
        pdelete = new javax.swing.JLabel();
        pupdate = new javax.swing.JLabel();
        pprice = new javax.swing.JTextField();
        pname = new javax.swing.JTextField();
        psearch = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        ptable = new javax.swing.JTable();
        pdescription = new javax.swing.JTextField();
        plid = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        padd = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.CardLayout());

        Metro.setPreferredSize(new java.awt.Dimension(1650, 1050));
        Metro.setLayout(null);

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Actions-list-add-icon.png"))); // NOI18N
        Metro.add(jLabel21);
        jLabel21.setBounds(470, 220, 50, 50);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("   Log Out");
        Metro.add(jLabel1);
        jLabel1.setBounds(1150, 280, 100, 22);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Statistics-icon.png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        Metro.add(jLabel2);
        jLabel2.setBounds(150, 150, 130, 130);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Actions-list-add-icon.png"))); // NOI18N
        Metro.add(jLabel4);
        jLabel4.setBounds(1050, 220, 50, 50);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Plate-icon.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        Metro.add(jLabel3);
        jLabel3.setBounds(380, 150, 130, 130);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        jLabel5.setText("Add Waiter");
        Metro.add(jLabel5);
        jLabel5.setBounds(990, 280, 100, 20);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Actions-list-add-user-icon.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        Metro.add(jLabel7);
        jLabel7.setBounds(600, 140, 130, 130);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 0, 0));
        jLabel8.setText("Add Order");
        Metro.add(jLabel8);
        jLabel8.setBounds(410, 280, 100, 20);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Log-Out-icon.png"))); // NOI18N
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        Metro.add(jLabel9);
        jLabel9.setBounds(1150, 140, 130, 130);

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Actions-list-add-icon.png"))); // NOI18N
        Metro.add(jLabel20);
        jLabel20.setBounds(870, 220, 50, 50);

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chef-icon.png"))); // NOI18N
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });
        Metro.add(jLabel19);
        jLabel19.setBounds(780, 140, 130, 130);

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 0, 0));
        jLabel11.setText("   Statistics");
        Metro.add(jLabel11);
        jLabel11.setBounds(160, 280, 100, 20);

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 0, 0));
        jLabel22.setText("Add Cashier");
        Metro.add(jLabel22);
        jLabel22.setBounds(610, 280, 100, 20);

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Occupations-Waiter-Male-Light-icon.png"))); // NOI18N
        jLabel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel23MouseClicked(evt);
            }
        });
        Metro.add(jLabel23);
        jLabel23.setBounds(970, 140, 130, 130);

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 0, 0));
        jLabel24.setText("Add Chef");
        Metro.add(jLabel24);
        jLabel24.setBounds(810, 280, 100, 20);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/pexels-photo-196519.jpeg"))); // NOI18N
        Metro.add(jLabel6);
        jLabel6.setBounds(0, 0, 1580, 850);

        getContentPane().add(Metro, "card2");

        Statistics.setPreferredSize(new java.awt.Dimension(1650, 1050));
        Statistics.setLayout(null);

        Chart.setText("Generate Chart");
        Chart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChartActionPerformed(evt);
            }
        });
        Statistics.add(Chart);
        Chart.setBounds(50, 60, 110, 60);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        Statistics.add(jScrollPane1);
        jScrollPane1.setBounds(670, 10, 690, 690);

        jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\abdelrhman\\Desktop\\back-icon.png")); // NOI18N
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel12MousePressed(evt);
            }
        });
        Statistics.add(jLabel12);
        jLabel12.setBounds(80, 430, 60, 50);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/pexels-photo(2).jpg"))); // NOI18N
        Statistics.add(jLabel10);
        jLabel10.setBounds(0, 0, 1580, 850);

        getContentPane().add(Statistics, "card3");

        Cashier.setPreferredSize(new java.awt.Dimension(1650, 1050));
        Cashier.setLayout(null);

        cdelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1_3.png"))); // NOI18N
        cdelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cdeleteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cdeleteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cdeleteMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cdeleteMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                cdeleteMouseReleased(evt);
            }
        });
        Cashier.add(cdelete);
        cdelete.setBounds(340, 320, 85, 40);

        cupdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1_2.png"))); // NOI18N
        cupdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cupdateMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cupdateMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cupdateMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cupdateMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                cupdateMouseReleased(evt);
            }
        });
        Cashier.add(cupdate);
        cupdate.setBounds(190, 320, 85, 40);
        Cashier.add(casheraddress);
        casheraddress.setBounds(150, 140, 190, 30);
        Cashier.add(cname);
        cname.setBounds(150, 80, 190, 30);

        csearch.setText("Search");
        csearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                csearchMouseClicked(evt);
            }
        });
        csearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                csearchActionPerformed(evt);
            }
        });
        Cashier.add(csearch);
        csearch.setBounds(720, 10, 180, 30);

        ctable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        ctable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ctableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(ctable);

        Cashier.add(jScrollPane2);
        jScrollPane2.setBounds(720, 50, 630, 740);
        Cashier.add(ccontact);
        ccontact.setBounds(150, 200, 190, 30);

        jLabel14.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Name:");
        Cashier.add(jLabel14);
        jLabel14.setBounds(70, 80, 52, 30);

        jLabel15.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Contact No:");
        Cashier.add(jLabel15);
        jLabel15.setBounds(20, 200, 100, 30);

        cadd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1.png"))); // NOI18N
        cadd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                caddMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                caddMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                caddMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                caddMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                caddMouseReleased(evt);
            }
        });
        Cashier.add(cadd);
        cadd.setBounds(40, 320, 85, 40);

        jLabel17.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Address:");
        Cashier.add(jLabel17);
        jLabel17.setBounds(50, 140, 80, 30);
        Cashier.add(casherid);
        casherid.setBounds(150, 30, 190, 30);

        jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\abdelrhman\\Desktop\\back-icon.png")); // NOI18N
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });
        Cashier.add(jLabel13);
        jLabel13.setBounds(30, 570, 100, 110);

        jLabel40.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("id:");
        Cashier.add(jLabel40);
        jLabel40.setBounds(90, 30, 52, 30);
        Cashier.add(csalary);
        csalary.setBounds(150, 250, 190, 30);

        jLabel39.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Salary:");
        Cashier.add(jLabel39);
        jLabel39.setBounds(20, 250, 100, 30);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/pexels-photo-210990.jpeg"))); // NOI18N
        Cashier.add(jLabel18);
        jLabel18.setBounds(0, 0, 1580, 850);

        getContentPane().add(Cashier, "card4");

        Chef.setPreferredSize(new java.awt.Dimension(1650, 1050));
        Chef.setLayout(null);

        shdelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1_3.png"))); // NOI18N
        shdelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shdeleteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                shdeleteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                shdeleteMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                shdeleteMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                shdeleteMouseReleased(evt);
            }
        });
        Chef.add(shdelete);
        shdelete.setBounds(340, 320, 85, 40);

        shupdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1_2.png"))); // NOI18N
        shupdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shupdateMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                shupdateMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                shupdateMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                shupdateMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                shupdateMouseReleased(evt);
            }
        });
        Chef.add(shupdate);
        shupdate.setBounds(190, 320, 85, 40);
        Chef.add(shaddress);
        shaddress.setBounds(150, 140, 190, 30);
        Chef.add(shname);
        shname.setBounds(150, 80, 190, 30);

        shsearch.setText("Search");
        shsearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shsearchMouseClicked(evt);
            }
        });
        shsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shsearchActionPerformed(evt);
            }
        });
        Chef.add(shsearch);
        shsearch.setBounds(720, 10, 180, 30);

        shtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        shtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shtableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(shtable);

        Chef.add(jScrollPane3);
        jScrollPane3.setBounds(720, 50, 630, 740);
        Chef.add(shcontact);
        shcontact.setBounds(150, 200, 190, 30);
        Chef.add(shid1);
        shid1.setBounds(150, 30, 190, 30);

        jLabel43.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("id:");
        Chef.add(jLabel43);
        jLabel43.setBounds(90, 30, 52, 30);
        Chef.add(shsalary);
        shsalary.setBounds(150, 250, 190, 30);

        jLabel44.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("Salary:");
        Chef.add(jLabel44);
        jLabel44.setBounds(20, 250, 100, 30);

        jLabel27.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Name:");
        Chef.add(jLabel27);
        jLabel27.setBounds(70, 80, 52, 30);

        jLabel28.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Contact No:");
        Chef.add(jLabel28);
        jLabel28.setBounds(20, 200, 100, 30);

        shadd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1.png"))); // NOI18N
        shadd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shaddMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                shaddMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                shaddMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                shaddMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                shaddMouseReleased(evt);
            }
        });
        Chef.add(shadd);
        shadd.setBounds(40, 320, 85, 40);

        jLabel26.setIcon(new javax.swing.ImageIcon("C:\\Users\\abdelrhman\\Desktop\\back-icon.png")); // NOI18N
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel26MouseClicked(evt);
            }
        });
        Chef.add(jLabel26);
        jLabel26.setBounds(100, 630, 100, 110);

        jLabel30.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Address:");
        Chef.add(jLabel30);
        jLabel30.setBounds(50, 140, 80, 30);

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/pexels-photo-29346.jpg"))); // NOI18N
        Chef.add(jLabel31);
        jLabel31.setBounds(0, 0, 1580, 850);

        getContentPane().add(Chef, "card4");

        Waiter.setPreferredSize(new java.awt.Dimension(1650, 1050));
        Waiter.setLayout(null);

        wdelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1_3.png"))); // NOI18N
        wdelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                wdeleteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                wdeleteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                wdeleteMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                wdeleteMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                wdeleteMouseReleased(evt);
            }
        });
        Waiter.add(wdelete);
        wdelete.setBounds(570, 320, 85, 40);

        wupdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1_2.png"))); // NOI18N
        wupdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                wupdateMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                wupdateMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                wupdateMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                wupdateMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                wupdateMouseReleased(evt);
            }
        });
        Waiter.add(wupdate);
        wupdate.setBounds(370, 320, 85, 40);
        Waiter.add(waddress);
        waddress.setBounds(310, 150, 190, 30);
        Waiter.add(wname);
        wname.setBounds(310, 100, 190, 30);

        wsearch.setText("Search");
        wsearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                wsearchMouseClicked(evt);
            }
        });
        wsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wsearchActionPerformed(evt);
            }
        });
        Waiter.add(wsearch);
        wsearch.setBounds(720, 10, 180, 30);

        wtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        wtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                wtableMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(wtable);

        Waiter.add(jScrollPane4);
        jScrollPane4.setBounds(720, 50, 630, 740);
        Waiter.add(wcontact);
        wcontact.setBounds(310, 200, 190, 30);

        jLabel34.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Name:");
        Waiter.add(jLabel34);
        jLabel34.setBounds(210, 100, 52, 30);

        jLabel35.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Contact No:");
        Waiter.add(jLabel35);
        jLabel35.setBounds(180, 200, 100, 30);

        wadd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1.png"))); // NOI18N
        wadd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                waddMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                waddMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                waddMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                waddMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                waddMouseReleased(evt);
            }
        });
        Waiter.add(wadd);
        wadd.setBounds(180, 320, 85, 40);
        Waiter.add(wid);
        wid.setBounds(310, 40, 190, 30);

        jLabel41.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("id:");
        Waiter.add(jLabel41);
        jLabel41.setBounds(240, 40, 52, 30);
        Waiter.add(wsalary);
        wsalary.setBounds(310, 250, 190, 30);

        jLabel42.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Salary:");
        Waiter.add(jLabel42);
        jLabel42.setBounds(180, 250, 100, 30);

        jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\abdelrhman\\Desktop\\back-icon.png")); // NOI18N
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });
        Waiter.add(jLabel16);
        jLabel16.setBounds(120, 540, 100, 110);

        jLabel37.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Address:");
        Waiter.add(jLabel37);
        jLabel37.setBounds(190, 150, 80, 30);

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/15817598_1158479010914886_1796620836_o.jpg"))); // NOI18N
        Waiter.add(jLabel38);
        jLabel38.setBounds(0, 0, 1580, 850);

        getContentPane().add(Waiter, "card4");

        newplate.setLayout(null);

        pdelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1_3.png"))); // NOI18N
        pdelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pdeleteMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pdeleteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pdeleteMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pdeleteMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                pdeleteMouseReleased(evt);
            }
        });
        newplate.add(pdelete);
        pdelete.setBounds(340, 320, 85, 40);

        pupdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1_2.png"))); // NOI18N
        pupdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pupdateMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pupdateMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pupdateMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                pupdateMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                pupdateMouseReleased(evt);
            }
        });
        newplate.add(pupdate);
        pupdate.setBounds(190, 320, 85, 40);
        newplate.add(pprice);
        pprice.setBounds(150, 140, 190, 30);
        newplate.add(pname);
        pname.setBounds(150, 80, 190, 30);

        psearch.setText("Search");
        psearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                psearchMouseClicked(evt);
            }
        });
        psearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                psearchActionPerformed(evt);
            }
        });
        newplate.add(psearch);
        psearch.setBounds(720, 10, 180, 30);

        ptable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        ptable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ptableMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(ptable);

        newplate.add(jScrollPane5);
        jScrollPane5.setBounds(720, 50, 630, 740);
        newplate.add(pdescription);
        pdescription.setBounds(150, 200, 190, 30);
        newplate.add(plid);
        plid.setBounds(150, 30, 190, 30);

        jLabel45.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("id:");
        newplate.add(jLabel45);
        jLabel45.setBounds(90, 30, 52, 30);

        jLabel29.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Name:");
        newplate.add(jLabel29);
        jLabel29.setBounds(70, 80, 52, 30);

        jLabel32.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Description:");
        newplate.add(jLabel32);
        jLabel32.setBounds(20, 200, 100, 30);

        padd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/Untitled-1.png"))); // NOI18N
        padd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paddMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                paddMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                paddMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                paddMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                paddMouseReleased(evt);
            }
        });
        newplate.add(padd);
        padd.setBounds(40, 320, 85, 40);

        jLabel25.setIcon(new javax.swing.ImageIcon("C:\\Users\\abdelrhman\\Desktop\\back-icon.png")); // NOI18N
        jLabel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel25MouseClicked(evt);
            }
        });
        newplate.add(jLabel25);
        jLabel25.setBounds(90, 560, 70, 110);

        jLabel33.setFont(new java.awt.Font("Brush Script MT", 0, 24)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Price:");
        newplate.add(jLabel33);
        jLabel33.setBounds(50, 140, 80, 30);

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images_2/red_lobster_seafood.jpg"))); // NOI18N
        newplate.add(jLabel36);
        jLabel36.setBounds(0, -100, 1580, 1010);

        getContentPane().add(newplate, "card4");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ChartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChartActionPerformed
     CreateChart CC = new CreateChart("Pie Chart Test","OS Comparison");
     CC.pack();
     CC.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     CC.setVisible(true);
        
        
    }//GEN-LAST:event_ChartActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        Statistics.setVisible(true);
        Metro.setVisible(false);
        
        
        
        
    }//GEN-LAST:event_jLabel2MouseClicked

    private void cdeleteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdeleteMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_3.png"));
        cdelete.setIcon(II);
    }//GEN-LAST:event_cdeleteMouseEntered

    private void cdeleteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdeleteMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1_3.png"));
        cdelete.setIcon(II);
    }//GEN-LAST:event_cdeleteMouseExited

    private void cdeleteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdeleteMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-3_3.png"));
        cdelete.setIcon(II);
    }//GEN-LAST:event_cdeleteMousePressed

    private void cdeleteMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdeleteMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_3.png"));
        cdelete.setIcon(II);
    }//GEN-LAST:event_cdeleteMouseReleased

    private void cupdateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cupdateMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_2.png"));
        cupdate.setIcon(II);
    }//GEN-LAST:event_cupdateMouseEntered

    private void cupdateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cupdateMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1_2.png"));
        cupdate.setIcon(II);
    }//GEN-LAST:event_cupdateMouseExited

    private void cupdateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cupdateMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-3_2.png"));
        cupdate.setIcon(II);
    }//GEN-LAST:event_cupdateMousePressed

    private void cupdateMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cupdateMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_2.png"));
        cupdate.setIcon(II);
    }//GEN-LAST:event_cupdateMouseReleased

    private void caddMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caddMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2.png"));
        cadd.setIcon(II);
    }//GEN-LAST:event_caddMouseEntered

    private void caddMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caddMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1.png"));
        cadd.setIcon(II);
    }//GEN-LAST:event_caddMouseExited

    private void caddMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caddMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-3.png"));
        cadd.setIcon(II);
    }//GEN-LAST:event_caddMousePressed

    private void caddMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caddMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2.png"));
        cadd.setIcon(II);
    }//GEN-LAST:event_caddMouseReleased

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        // TODO add your handling code here:
        
        GetData("plate");
        newplate.setVisible(true);
        Metro.setVisible(false);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void shdeleteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shdeleteMouseEntered
        // TODO add your handling code here:
        
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_3.png"));
        shdelete.setIcon(II);

    }//GEN-LAST:event_shdeleteMouseEntered

    private void shdeleteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shdeleteMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1_3.png"));
        shdelete.setIcon(II);


    }//GEN-LAST:event_shdeleteMouseExited

    private void shdeleteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shdeleteMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-3_3.png"));
        shdelete.setIcon(II);
    }//GEN-LAST:event_shdeleteMousePressed

    private void shdeleteMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shdeleteMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_3.png"));
        shdelete.setIcon(II);
    }//GEN-LAST:event_shdeleteMouseReleased

    private void shupdateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shupdateMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_2.png"));
        shupdate.setIcon(II);
        
    }//GEN-LAST:event_shupdateMouseEntered

    private void shupdateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shupdateMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1_2.png"));
        shupdate.setIcon(II);
    }//GEN-LAST:event_shupdateMouseExited

    private void shupdateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shupdateMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1_2.png"));
        shupdate.setIcon(II);
    }//GEN-LAST:event_shupdateMousePressed

    private void shupdateMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shupdateMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_2.png"));
        shupdate.setIcon(II);
    }//GEN-LAST:event_shupdateMouseReleased

    private void shaddMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shaddMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2.png"));
        shadd.setIcon(II);
    }//GEN-LAST:event_shaddMouseEntered

    private void shaddMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shaddMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1.png"));
        shadd.setIcon(II);
    }//GEN-LAST:event_shaddMouseExited

    private void shaddMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shaddMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-3.png"));
        shadd.setIcon(II);
    }//GEN-LAST:event_shaddMousePressed

    private void shaddMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shaddMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2.png"));
        shadd.setIcon(II);
    }//GEN-LAST:event_shaddMouseReleased

    private void wdeleteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wdeleteMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_3.png"));
        wdelete.setIcon(II);
        
    }//GEN-LAST:event_wdeleteMouseEntered

    private void wdeleteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wdeleteMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1_3.png"));
        wdelete.setIcon(II);
    }//GEN-LAST:event_wdeleteMouseExited

    private void wdeleteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wdeleteMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-3_3.png"));
        wdelete.setIcon(II);
    }//GEN-LAST:event_wdeleteMousePressed

    private void wdeleteMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wdeleteMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_3.png"));
        wdelete.setIcon(II);
    }//GEN-LAST:event_wdeleteMouseReleased

    private void wupdateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wupdateMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_2.png"));
        wupdate.setIcon(II);
        
        
    }//GEN-LAST:event_wupdateMouseEntered

    private void wupdateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wupdateMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1_2.png"));
        wupdate.setIcon(II);
        
    }//GEN-LAST:event_wupdateMouseExited

    private void wupdateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wupdateMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-3_2.png"));
        wupdate.setIcon(II);
    }//GEN-LAST:event_wupdateMousePressed

    private void wupdateMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wupdateMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2_2.png"));
        wupdate.setIcon(II);

    }//GEN-LAST:event_wupdateMouseReleased

    private void waddMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_waddMouseEntered
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2.png"));
        wadd.setIcon(II);
        
    }//GEN-LAST:event_waddMouseEntered

    private void waddMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_waddMouseExited
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-1.png"));
        wadd.setIcon(II);

    }//GEN-LAST:event_waddMouseExited

    private void waddMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_waddMousePressed
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-3.png"));
        wadd.setIcon(II);
        
    }//GEN-LAST:event_waddMousePressed

    private void waddMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_waddMouseReleased
        // TODO add your handling code here:
        ImageIcon II = new  ImageIcon(getClass().getResource("/Images_2/Untitled-2.png"));
        wadd.setIcon(II);
        
    }//GEN-LAST:event_waddMouseReleased

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        // TODO add your handling code here:
        Chef.setVisible(true);
        Metro.setVisible(false);
        GetData("cheff");
            
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jLabel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel23MouseClicked
        // TODO add your handling code here:
        Waiter.setVisible(true);
        Metro.setVisible(false);
        GetData("waiter");
    }//GEN-LAST:event_jLabel23MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        // TODO add your handling code here:
        Cashier.setVisible(true);
        Metro.setVisible(false);
        GetData("casher");
    }//GEN-LAST:event_jLabel7MouseClicked

    private void waddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_waddMouseClicked
        // TODO add your handling code here:
     String Name = wname.getText();
     String Address =waddress .getText();
     String Contact =wcontact .getText();
     int salary =Integer.parseInt(wsalary .getText());
 
    
       
         try {
             Connection s=getConnection("c");
         
            if((!"".equals(wid.getText()))&&(( !"".equals(Contact))||(!"".equals(Name)))){
                    
             String query = "INSERT INTO `waiter`(`idwaiter`,`waitername`, `address`, `contactno`, `salary`) "
              + "VALUES (?,?,?,?,?)";
            PreparedStatement stat=s.prepareStatement(query);
            int ID = Integer.parseInt(wid.getText());
             stat.setInt(1, ID);
            
            stat.setString(2, Name);

            stat.setString(3, Address);

            stat.setString(4, Contact);
            stat.setInt(5, salary);
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
            }
            else if("".equals(wid.getText())){
                    
            String query = "INSERT INTO `waiter`(`waitername`, `address`, `contactno`, `salary`) "
              + "VALUES (?,?,?,?)";
             //String d="select idcustomer from customer ";
            PreparedStatement stat=s.prepareStatement(query);
                
            stat.setString(1, Name);

            stat.setString(2, Address);

            stat.setString(3, Contact);
            stat.setInt(4, salary);
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
                        JOptionPane.showMessageDialog(null, " id is outo incrment");

            }
           else
                JOptionPane.showMessageDialog(null, " pleas fill name or contact");
            
        GetData("waiter");
             
         s.close();
            }
            


            
            
        catch (SQLException ex) {
            
            
            if (("".equals(Address)) ){
                      JOptionPane.showMessageDialog(null, "address is empty");  

            
            }
            
            
            
            else if(( "".equals(Contact))&&("".equals(Name))){
            
            JOptionPane.showMessageDialog(null, "address is contact and name are empty");
            }
            
          
           else
        JOptionPane.showMessageDialog(null, "Duplicated entry change id");  
        
        }

    }//GEN-LAST:event_waddMouseClicked

    private void caddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caddMouseClicked
        // TODO add your handling code here: casher
                // TODO add your handling code here:
           
        String Name = cname.getText();
     String Address =casheraddress .getText();
     String Contact =ccontact .getText();
     int salary =Integer.parseInt(csalary .getText());
 
   //  methodes g= new methodes();
       
         try {
             Connection s=getConnection("c");
         
            if((!"".equals(casherid.getText()))&&(( !"".equals(Contact))||(!"".equals(Name)))){
                    
             String query = "INSERT INTO `casher`(`casherid`,`cashername`, `address`, `contactno`, `salary`) "
              + "VALUES (?,?,?,?,?)";
            PreparedStatement stat=s.prepareStatement(query);
            int ID = Integer.parseInt(casherid.getText());
             stat.setInt(1, ID);
            
            stat.setString(2, Name);

            stat.setString(3, Address);

            stat.setString(4, Contact);
            stat.setInt(5, salary);
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
            }
            else if("".equals(casherid.getText())){
                    
            String query = "INSERT INTO `casher`(`cashername`, `address`, `contactno`, `salary`) "
              + "VALUES (?,?,?,?)";
             //String d="select idcustomer from customer ";
            PreparedStatement stat=s.prepareStatement(query);
                
            stat.setString(1, Name);

            stat.setString(2, Address);

            stat.setString(3, Contact);
            stat.setInt(4, salary);
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
                        JOptionPane.showMessageDialog(null, " id is outo incrment");

            }
           else
                JOptionPane.showMessageDialog(null, " pleas fill name or contact");
            
        GetData("casher");
             
         s.close();
            }
            


            
            
        catch (SQLException ex) {
            
            
            if (("".equals(Address)) ){
                      JOptionPane.showMessageDialog(null, "address is empty");  

            
            }
            
            
            
            else if(( "".equals(Contact))&&("".equals(Name))){
            
            JOptionPane.showMessageDialog(null, "address is contact and name are empty");
            }
            
          
           else
        JOptionPane.showMessageDialog(null, "Duplicated entry change id");  
        
        }

        
        
        
    }//GEN-LAST:event_caddMouseClicked

    private void cupdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cupdateMouseClicked
        // TODO add your handling code here:
        
        
        
        try {
           Connection s=getConnection("c");

            String Address = casheraddress.getText();
            String contactNo = ccontact .getText();
             
            String Name = cname.getText();
        String salary = csalary.getText();
      String query = "UPDATE casher SET cashername=? ,address=? ,contactno=? ,salary=?"
                + " WHERE `casherid` = "+casherid.getText();
        // create the mysql insert preparedstatement
      PreparedStatement preparedStmt = s.prepareStatement(query);
      preparedStmt.setString (1, Name);
      
     
      
      preparedStmt.setString(2,Address);
      
       preparedStmt.setString(3,contactNo);
       preparedStmt.setString(4,salary);
      
      
      preparedStmt.executeUpdate();
     GetData("casher");
      s.close();
      
        } catch (SQLException ex) { 
        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
    } 
                                       

                             

  
   
        
        
    }//GEN-LAST:event_cupdateMouseClicked

    private void ctableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ctableMouseClicked
        // TODO add your handling code here:
        
        jTableClicked("ctable");
    }//GEN-LAST:event_ctableMouseClicked

    private void wupdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wupdateMouseClicked
        // TODO add your handling code here:
        
               try {
           Connection s=getConnection("c");

            String Address = waddress.getText();
            String contactNo = wcontact .getText();
             
            String Name = wname.getText();
        String salary = wsalary.getText();
      String query = "UPDATE waiter SET waitername=? ,address=? ,contactno=? ,salary=?"
                + " WHERE `idwaiter` = "+wid.getText();
        // create the mysql insert preparedstatement
      PreparedStatement preparedStmt = s.prepareStatement(query);
      preparedStmt.setString (1, Name);
      
     
      
      preparedStmt.setString(2,Address);
      
       preparedStmt.setString(3,contactNo);
       preparedStmt.setString(4,salary);
      
      
      preparedStmt.executeUpdate();
     GetData("waiter");
      s.close();
      
        } catch (SQLException ex) { 
        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
    } 
    }//GEN-LAST:event_wupdateMouseClicked

    private void shupdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shupdateMouseClicked
        // TODO add your handling code here:
        
        
               try {
           Connection s=getConnection("c");

            String Address = shaddress.getText();
            String contactNo = shcontact .getText();
             
            String Name = shname.getText();
        String salary = shsalary.getText();
      String query = "UPDATE casher SET cheffname=? ,address=? ,contactno=? ,salary=?"
                + " WHERE `idcheff` = "+shid1.getText();
        // create the mysql insert preparedstatement
      PreparedStatement preparedStmt = s.prepareStatement(query);
      preparedStmt.setString (1, Name);
      
     
      
      preparedStmt.setString(2,Address);
      
       preparedStmt.setString(3,contactNo);
       preparedStmt.setString(4,salary);
      
      
      preparedStmt.executeUpdate();
     GetData("cheff");
      s.close();
      
        } catch (SQLException ex) { 
        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
    } 
    }//GEN-LAST:event_shupdateMouseClicked

    private void shaddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shaddMouseClicked
        // TODO add your handling code here:
        
        String Name = shname.getText();
     String Address =shaddress .getText();
     String Contact =shcontact .getText();
     int salary =Integer.parseInt(shsalary .getText());
 

       
         try {
             Connection s=getConnection("c");
         
            if((!"".equals(shid1.getText()))&&(( !"".equals(Contact))||(!"".equals(Name)))){
                    
             String query = "INSERT INTO `cheff`(`idcheff`,`cheffname`, `address`, `contactno`, `salary`) "
              + "VALUES (?,?,?,?,?)";
            PreparedStatement stat=s.prepareStatement(query);
            int ID = Integer.parseInt(shid1.getText());
             stat.setInt(1, ID);
            
            stat.setString(2, Name);

            stat.setString(3, Address);

            stat.setString(4, Contact);
            stat.setInt(5, salary);
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
            }
            else if("".equals(shid1.getText())){
                    
            String query = "INSERT INTO `cheff`(`cheffname`, `address`, `contactno`, `salary`) "
              + "VALUES (?,?,?,?)";
             //String d="select idcustomer from customer ";
            PreparedStatement stat=s.prepareStatement(query);
                
            stat.setString(1, Name);

            stat.setString(2, Address);

            stat.setString(3, Contact);
            stat.setInt(4, salary);
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
                        JOptionPane.showMessageDialog(null, " id is outo incrment");

            }
           else
                JOptionPane.showMessageDialog(null, " pleas fill name or contact");
            
        GetData("cheff");
             
         s.close();
            }
            


            
            
        catch (SQLException ex) {
            
            
            if (("".equals(Address)) ){
                      JOptionPane.showMessageDialog(null, "address is empty");  

            
            }
            
            
            
            else if(( "".equals(Contact))&&("".equals(Name))){
            
            JOptionPane.showMessageDialog(null, "address is contact and name are empty");
            }
            
          
           else
        JOptionPane.showMessageDialog(null, "Duplicated entry change id");  
        
        }
    }//GEN-LAST:event_shaddMouseClicked

    private void cdeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cdeleteMouseClicked
        // TODO add your handling code here:
        try { // hapus data
            String sql ="delete from casher where casherid='"+casherid.getText()+"'";
            Connection conn =  getConnection("c");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Data akan dihapus?");
            
            
            
            casherid.setText("");
            cname.setText("");
            casheraddress.setText("");
            ccontact.setText("");
            csalary.setText("");
             GetData("casher");
        } catch (SQLException | HeadlessException e){
                    JOptionPane.showMessageDialog(null, "Delete fail");             

            
        }
        
        
    }//GEN-LAST:event_cdeleteMouseClicked

    private void shdeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shdeleteMouseClicked
        // TODO add your handling code here:
        try { // hapus data
            String sql ="delete from cheff where idcheff='"+shid1.getText()+"'";
            Connection conn =  getConnection("c");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Data akan dihapus?");
            
            
            
            shid1.setText("");
            shname.setText("");
            shaddress.setText("");
            shcontact.setText("");
            shsalary.setText("");
             GetData("cheff");
        } catch (SQLException | HeadlessException e){
                    JOptionPane.showMessageDialog(null, "Delete fail");             

            
        }
    }//GEN-LAST:event_shdeleteMouseClicked

    private void wdeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wdeleteMouseClicked
        // TODO add your handling code here:
        
         try { // hapus data
            String sql ="delete from waiter where idwaiter='"+wid.getText()+"'";
            Connection conn =  getConnection("c");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Data akan dihapus?");
            
            
            
            wid.setText("");
            wname.setText("");
            waddress.setText("");
            wcontact.setText("");
            wsalary.setText("");
             GetData("waiter");
        } catch (SQLException | HeadlessException e){
                    JOptionPane.showMessageDialog(null, "Delete fail");             

            
        }
    }//GEN-LAST:event_wdeleteMouseClicked

    private void wtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wtableMouseClicked
        // TODO add your handling code here:
        
        jTableClicked("wtable");
    }//GEN-LAST:event_wtableMouseClicked

    private void shtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shtableMouseClicked
        // TODO add your handling code here:
        
        jTableClicked("shtable");
    }//GEN-LAST:event_shtableMouseClicked

    private void wsearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_wsearchMouseClicked
        // TODO add your handling code here:
        
          wsearch.setText("");
    }//GEN-LAST:event_wsearchMouseClicked

    private void shsearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shsearchMouseClicked
        // TODO add your handling code here:
        
        shsearch.setText("");
    }//GEN-LAST:event_shsearchMouseClicked

    private void csearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_csearchMouseClicked
        // TODO add your handling code here:
        
        csearch.setText("");
    }//GEN-LAST:event_csearchMouseClicked

    private void csearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_csearchActionPerformed
        // TODO add your handling code here:
         GetData("casher");
        findCashers();
       
    }//GEN-LAST:event_csearchActionPerformed

    private void wsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wsearchActionPerformed
        // TODO add your handling code here:
        
        GetData("waiter");
        findwaiter();
    }//GEN-LAST:event_wsearchActionPerformed

    private void shsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shsearchActionPerformed
        // TODO add your handling code here:
        
        
        GetData("cheff");
        findcheff();
    }//GEN-LAST:event_shsearchActionPerformed

    private void pdeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pdeleteMouseClicked
        // TODO add your handling code here:
        
         try { // hapus data
            String sql ="delete from iteams where iteamNo='"+plid.getText()+"'";
            Connection conn =  getConnection("c");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "delete?");
            
            
            
            plid.setText("");
            pname.setText("");
            pprice.setText("");
            pdescription.setText("");
           
             GetData("plate");
        } catch (SQLException | HeadlessException e){
                    JOptionPane.showMessageDialog(null, "Delete fail");             

            
        }
    }//GEN-LAST:event_pdeleteMouseClicked

    private void pdeleteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pdeleteMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_pdeleteMouseEntered

    private void pdeleteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pdeleteMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_pdeleteMouseExited

    private void pdeleteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pdeleteMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_pdeleteMousePressed

    private void pdeleteMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pdeleteMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_pdeleteMouseReleased

    private void pupdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pupdateMouseClicked
        // TODO add your handling code here:
        
        
          try {
           Connection s=getConnection("c");

            String name = pname.getText();
            String price = pprice .getText();
             
            String description = pdescription.getText();
        
      String query = "UPDATE iteams SET name=? ,price=? ,description=? "
                + " WHERE `idwaiter` = "+wid.getText();
        // create the mysql insert preparedstatement
      PreparedStatement preparedStmt = s.prepareStatement(query);
      preparedStmt.setString (1, name);
      
     
      
      preparedStmt.setString(2,price);
      
       preparedStmt.setString(3,description);
      
      
      
      preparedStmt.executeUpdate();
     GetData("plate");
      s.close();
      
        } catch (SQLException ex) { 
        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
    } 
                                        

    
    }//GEN-LAST:event_pupdateMouseClicked

    private void pupdateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pupdateMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_pupdateMouseEntered

    private void pupdateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pupdateMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_pupdateMouseExited

    private void pupdateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pupdateMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_pupdateMousePressed

    private void pupdateMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pupdateMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_pupdateMouseReleased

    private void psearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_psearchMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_psearchMouseClicked

    private void psearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_psearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_psearchActionPerformed

    private void ptableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ptableMouseClicked
        // TODO add your handling code here:
        
        jTableClicked("plate");
    }//GEN-LAST:event_ptableMouseClicked

    private void paddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paddMouseClicked
        // TODO add your handling code here:
        
        String Name = pname.getText();

     String description =pdescription .getText();
     int price =Integer.parseInt(pprice .getText());

       
         try {
             Connection s=getConnection("c");
         
            if((!"".equals(plid.getText()))&&(( !"".equals(price))||(!"".equals(Name)))){
                    
             String query = "INSERT INTO `iteams`(`iteamNo`,`name`, `price`, `description`) "
              + "VALUES (?,?,?,?)";
            PreparedStatement stat=s.prepareStatement(query);
            int ID = Integer.parseInt(plid.getText());
             stat.setInt(1, ID);
            
            stat.setString(2, Name);

            stat.setInt(3, price);

            stat.setString(4, description);
            
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
            }
            else if("".equals(plid.getText())){
                    
            String query = "INSERT INTO `iteams`( `name`, `price`, `description`) "
              + "VALUES (?,?,?)";
             //String d="select idcustomer from customer ";
            PreparedStatement stat=s.prepareStatement(query);
                
            stat.setString(1, Name);

            stat.setInt(2, price);

            stat.setString(3, description);
          
            JOptionPane.showMessageDialog(null, "insert");
            stat.executeUpdate();
            
                        JOptionPane.showMessageDialog(null, " id is outo incrment");

            }
           else
                JOptionPane.showMessageDialog(null, " pleas fill name or contact");
            
        GetData("plate");
             
         s.close();
            }
            


            
            
        catch (SQLException ex) {
            
            
            if (("".equals(price)) ){
                      JOptionPane.showMessageDialog(null, "price is empty");  

            
            }
            
            
            
            else if(( "".equals(description))&&("".equals(Name))){
            
            JOptionPane.showMessageDialog(null, "description and name are empty");
            }
            
          
           else
        JOptionPane.showMessageDialog(null, "Duplicated entry change id");  
        
        }
    
        
        
    }//GEN-LAST:event_paddMouseClicked

    private void paddMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paddMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_paddMouseEntered

    private void paddMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paddMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_paddMouseExited

    private void paddMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paddMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_paddMousePressed

    private void paddMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paddMouseReleased
        // TODO add your handling code here:
        
         
    }//GEN-LAST:event_paddMouseReleased

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        // TODO add your handling code here:
        Statistics.setVisible(false);
        Metro.setVisible(true);

    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        // TODO add your handling code here:

        Cashier.setVisible(false);
         Metro.setVisible(true);
       
    }//GEN-LAST:event_jLabel13MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        // TODO add your handling code here:
        
            
        Waiter.setVisible(false);
         Metro.setVisible(true);
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jLabel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MouseClicked
        // TODO add your handling code here:
            
        newplate.setVisible(false);
         Metro.setVisible(true);
      
    }//GEN-LAST:event_jLabel25MouseClicked

    private void jLabel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseClicked
        // TODO add your handling code here:
        
        Chef.setVisible(false);
         Metro.setVisible(true);
    }//GEN-LAST:event_jLabel26MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
         Metro.setVisible(false);
        
         NewJFrame_2 y = new NewJFrame_2();
        y.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel12MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MousePressed
        // TODO add your handling code here:
       
        
    }//GEN-LAST:event_jLabel12MousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Cashier;
    private javax.swing.JButton Chart;
    private javax.swing.JPanel Chef;
    private javax.swing.JPanel Metro;
    private javax.swing.JPanel Statistics;
    private javax.swing.JPanel Waiter;
    private javax.swing.JLabel cadd;
    private javax.swing.JTextField casheraddress;
    private javax.swing.JTextField casherid;
    private javax.swing.JTextField ccontact;
    private javax.swing.JLabel cdelete;
    private javax.swing.JTextField cname;
    private javax.swing.JTextField csalary;
    private javax.swing.JTextField csearch;
    private javax.swing.JTable ctable;
    private javax.swing.JLabel cupdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JPanel newplate;
    private javax.swing.JLabel padd;
    private javax.swing.JLabel pdelete;
    private javax.swing.JTextField pdescription;
    private javax.swing.JTextField plid;
    private javax.swing.JTextField pname;
    private javax.swing.JTextField pprice;
    private javax.swing.JTextField psearch;
    private javax.swing.JTable ptable;
    private javax.swing.JLabel pupdate;
    private javax.swing.JLabel shadd;
    private javax.swing.JTextField shaddress;
    private javax.swing.JTextField shcontact;
    private javax.swing.JLabel shdelete;
    private javax.swing.JTextField shid1;
    private javax.swing.JTextField shname;
    private javax.swing.JTextField shsalary;
    private javax.swing.JTextField shsearch;
    private javax.swing.JTable shtable;
    private javax.swing.JLabel shupdate;
    private javax.swing.JLabel wadd;
    private javax.swing.JTextField waddress;
    private javax.swing.JTextField wcontact;
    private javax.swing.JLabel wdelete;
    private javax.swing.JTextField wid;
    private javax.swing.JTextField wname;
    private javax.swing.JTextField wsalary;
    private javax.swing.JTextField wsearch;
    private javax.swing.JTable wtable;
    private javax.swing.JLabel wupdate;
    // End of variables declaration//GEN-END:variables
}
