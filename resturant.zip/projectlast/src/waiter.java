

public class waiter {
    
    private int id;
    private String address;
    private String name;
    private int contact;
      private int salary;
    
    public waiter(int idwaiter,String waitername,String address,int contactno,int salary)
    {
        this.id = idwaiter;
        this.name = waitername;
        this.address = address;
        this.contact = contactno;
          this.contact = salary;
    }
    
    public int getidwaiter()
    {
        return id;
    }
     public int getsalarywaiter()
    {
        return salary;
    }
    
    public String getwaiterName()
    {
        return name;
    }
    
    public String getwaiteraddress()
    {
        return address;
    }
    
    public int getwaitercontactno()
    {
        return contact;
    }
    
      
    
}
